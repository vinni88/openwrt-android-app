package ru.wpressclub.openwrtandroidapp

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Typeface
import android.net.http.SslError
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

class MainActivity : AppCompatActivity() {

    private lateinit var rootContainer: FrameLayout
    private lateinit var mainWebView: WebView
    private lateinit var luciOverlay: LinearLayout
    private lateinit var luciTitleView: TextView
    private lateinit var luciWebView: WebView

    private val sshManager = SshManager()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var luciUser: String = "root"
    private var luciPass: String = ""

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        super.onCreate(savedInstanceState)
        trustAllCertificates()

        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.parseColor("#080B0F")

        rootContainer = FrameLayout(this)
        rootContainer.setBackgroundColor(Color.BLACK)
        setContentView(rootContainer)

        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)

        mainWebView = WebView(this)
        mainWebView.setBackgroundColor(Color.BLACK)
        configureWebView(mainWebView, forceDarkPage = false)
        mainWebView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = false

            @SuppressLint("WebViewClientOnReceivedSslError")
            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                handler?.proceed()
            }
        }
        mainWebView.addJavascriptInterface(RouterBridge(), "AndroidBridge")
        rootContainer.addView(
            mainWebView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        setupLuciOverlay()

        mainWebView.loadUrl("file:///android_asset/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (luciOverlay.visibility == View.VISIBLE) {
                    if (luciWebView.canGoBack()) {
                        luciWebView.goBack()
                    } else {
                        closeLuciOverlay()
                    }
                }
            }
        })
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Suppress("DEPRECATION")
    private fun configureWebView(wv: WebView, forceDarkPage: Boolean) {
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.builtInZoomControls = true
        s.displayZoomControls = false

        if (forceDarkPage) {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
                WebSettingsCompat.setAlgorithmicDarkeningAllowed(s, true)
            }
            if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
                WebSettingsCompat.setForceDark(s, WebSettings.FORCE_DARK_ON)
            }
            if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK_STRATEGY)) {
                WebSettingsCompat.setForceDarkStrategy(
                    s,
                    WebSettingsCompat.DARK_STRATEGY_USER_AGENT_DARKENING_ONLY
                )
            }
        }
        wv.webChromeClient = WebChromeClient()
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    private fun applyLuciDarkTheme(view: WebView?) {
        val darkCssJs = """
            (function() {
                if (!document.getElementById('__owrt_force_dark')) {
                    var st = document.createElement('style');
                    st.id = '__owrt_force_dark';
                    st.textContent =
                        'html, body { background-color: #000000 !important; color: #ffffff !important; color-scheme: dark !important; } ' +
                        'header, .navbar, .main-left, .main-right, #maincontent, .container, .cbi-map, .cbi-section, .cbi-section-node, .table, .tr, .td, .th, fieldset, .panel, .card, .modal { ' +
                        '  background-color: #0d1117 !important; color: #ffffff !important; border-color: #1c2533 !important; ' +
                        '} ' +
                        'header, .navbar { background-color: #080b0f !important; } ' +
                        'input, select, textarea { background-color: #151c26 !important; color: #ffffff !important; border: 1px solid #263244 !important; } ' +
                        'a, .brand, h1, h2, h3, legend { color: #4ce5b6 !important; } ' +
                        '.btn, button, input[type="button"], input[type="submit"] { background-color: #151c26 !important; color: #ffffff !important; border: 1px solid #263244 !important; } ' +
                        '.cbi-button-save, .cbi-button-apply, .cbi-button-positive { background-color: #4ce5b6 !important; color: #000000 !important; font-weight: 700 !important; } ' +
                        '.cbi-button-reset, .cbi-button-negative, .cbi-button-remove { background-color: #3a161b !important; color: #ff6b6b !important; }';
                    (document.head || document.documentElement).appendChild(st);
                }
            })();
        """.trimIndent()
        view?.evaluateJavascript(darkCssJs, null)
    }

    private fun switchToTabFromOverlay(tabName: String) {
        closeLuciOverlay()
        mainWebView.evaluateJavascript("if(window.switchTab){window.switchTab('$tabName');}", null)
    }

    private fun setupLuciOverlay() {
        luciOverlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            visibility = View.GONE
        }

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#080B0F"))
            setPadding(dp(14), dp(10), dp(14), dp(10))
            gravity = Gravity.CENTER_VERTICAL
        }

        luciTitleView = TextView(this).apply {
            text = "Панель LuCI"
            setTextColor(Color.parseColor("#4CE5B6"))
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }

        val closeBtn = TextView(this).apply {
            text = "Закрыть"
            setTextColor(Color.parseColor("#FF5C5C"))
            setBackgroundColor(Color.parseColor("#2A1418"))
            textSize = 13f
            setTypeface(null, Typeface.BOLD)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setOnClickListener { closeLuciOverlay() }
        }

        topBar.addView(luciTitleView)
        topBar.addView(closeBtn)

        luciWebView = WebView(this)
        luciWebView.setBackgroundColor(Color.BLACK)
        configureWebView(luciWebView, forceDarkPage = true)
        luciWebView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = false

            @SuppressLint("WebViewClientOnReceivedSslError")
            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                handler?.proceed()
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                applyLuciDarkTheme(view)
            }

            override fun onPageCommitVisible(view: WebView?, url: String?) {
                super.onPageCommitVisible(view, url)
                applyLuciDarkTheme(view)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                applyLuciDarkTheme(view)
                val uEsc = JSONObject.quote(luciUser)
                val pEsc = JSONObject.quote(luciPass)
                val autoLoginJs = """
                    (function() {
                        var inputs = document.getElementsByTagName('input');
                        var u = null, p = null;
                        for (var i = 0; i < inputs.length; i++) {
                            if (inputs[i].name === 'luci_username') u = inputs[i];
                            if (inputs[i].name === 'luci_password') p = inputs[i];
                        }
                        if (u && p && !window.__luciSubmitted) {
                            window.__luciSubmitted = true;
                            u.value = $uEsc;
                            p.value = $pEsc;
                            var f = p.closest('form');
                            if (f) f.submit();
                        }
                    })();
                """.trimIndent()
                view?.evaluateJavascript(autoLoginJs, null)
            }
        }

        // Постоянный нижний бар навигации внутри окна LuCI
        val bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#080B0F"))
            setPadding(dp(4), dp(8), dp(4), dp(10))
            weightSum = 4f
        }

        val tabs = listOf(
            "Обзор" to "overview",
            "Сервисы" to "services",
            "Клиенты" to "clients",
            "Терминал" to "terminal"
        )

        tabs.forEach { (label, tabKey) ->
            val btn = TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                textSize = 12.5f
                setTypeface(null, Typeface.BOLD)
                setTextColor(if (tabKey == "overview") Color.parseColor("#4CE5B6") else Color.parseColor("#CBD5E1"))
                setPadding(dp(4), dp(8), dp(4), dp(8))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { switchToTabFromOverlay(tabKey) }
            }
            bottomBar.addView(btn)
        }

        luciOverlay.addView(
            topBar,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        luciOverlay.addView(
            luciWebView,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        luciOverlay.addView(
            bottomBar,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        rootContainer.addView(
            luciOverlay,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
    }

    private fun closeLuciOverlay() {
        luciOverlay.visibility = View.GONE
        luciWebView.loadUrl("about:blank")
    }

    private fun trustAllCertificates() {
        try {
            val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
                override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}
                override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
                override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
            })
            val sc = SSLContext.getInstance("TLS")
            sc.init(null, trustAllCerts, SecureRandom())
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.socketFactory)
            HttpsURLConnection.setDefaultHostnameVerifier { _, _ -> true }
        } catch (_: Exception) {
        }
    }

    inner class RouterBridge {

        @JavascriptInterface
        fun openLuci(fullUrl: String, title: String, user: String, pass: String) {
            scope.launch(Dispatchers.Main) {
                luciUser = user
                luciPass = pass
                luciTitleView.text = title
                luciOverlay.visibility = View.VISIBLE
                luciWebView.loadUrl(fullUrl)
            }
        }

        @JavascriptInterface
        fun ubusCall(callbackId: String, routerUrl: String, payloadJson: String) {
            scope.launch(Dispatchers.IO) {
                val responseJson = JSONObject()
                try {
                    val cleanBase = routerUrl.trim().trimEnd('/')
                    val endpoint = "$cleanBase/ubus"
                    val url = URL(endpoint)
                    val conn = url.openConnection() as HttpURLConnection
                    conn.requestMethod = "POST"
                    conn.connectTimeout = 7000
                    conn.readTimeout = 10000
                    conn.doOutput = true
                    conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")

                    OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
                        writer.write(payloadJson)
                    }

                    val code = conn.responseCode
                    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                    val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""

                    responseJson.put("ok", code in 200..299)
                    responseJson.put("code", code)
                    responseJson.put("body", body)
                } catch (e: Exception) {
                    responseJson.put("ok", false)
                    responseJson.put("error", e.message ?: "Ошибка сети")
                }

                val js = "window.__onNativeCallback('$callbackId', ${JSONObject.quote(responseJson.toString())});"
                scope.launch(Dispatchers.Main) {
                    mainWebView.evaluateJavascript(js, null)
                }
            }
        }

        @JavascriptInterface
        fun sshExec(callbackId: String, routerUrl: String, sshPort: Int, user: String, pass: String, command: String) {
            scope.launch {
                val host = extractHost(routerUrl)
                val res = sshManager.execCommand(host, sshPort, user, pass, command)
                val json = JSONObject()
                if (res.isSuccess) {
                    json.put("ok", true)
                    json.put("output", res.getOrDefault(""))
                } else {
                    json.put("ok", false)
                    json.put("error", res.exceptionOrNull()?.message ?: "Ошибка SSH")
                }
                val js = "window.__onNativeCallback('$callbackId', ${JSONObject.quote(json.toString())});"
                mainWebView.evaluateJavascript(js, null)
            }
        }

        private fun extractHost(rawUrl: String): String {
            return try {
                val normalized = if (rawUrl.startsWith("http://") || rawUrl.startsWith("https://")) rawUrl else "http://$rawUrl"
                URI(normalized).host ?: rawUrl.replace("http://", "").replace("https://", "").split(":")[0].split("/")[0]
            } catch (_: Exception) {
                rawUrl.replace("http://", "").replace("https://", "").split(":")[0].split("/")[0]
            }
        }
    }
}
