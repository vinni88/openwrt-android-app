package ru.wpressclub.openwrtandroidapp

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.net.http.SslError
import android.os.Bundle
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

class MainActivity : AppCompatActivity() {

    private lateinit var rootContainer: FrameLayout
    private lateinit var mainWebView: WebView
    private lateinit var luciOverlay: LinearLayout
    private lateinit var luciTitleView: TextView
    private lateinit var luciWebView: WebView
    private val overlayNavItems = mutableMapOf<String, Pair<ImageView, TextView>>()

    private val sshManager = SshManager()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var luciUser: String = "root"
    private var luciPass: String = ""
    private var luciEntryUrl: String = ""

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        super.onCreate(savedInstanceState)
        trustAllCertificates()

        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.parseColor("#080B0F")

        rootContainer = FrameLayout(this)
        rootContainer.setBackgroundColor(Color.BLACK)
        setContentView(rootContainer)

        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)

        mainWebView = WebView(this)
        mainWebView.setBackgroundColor(Color.BLACK)
        configureWebView(mainWebView, forceDarkPage = false)
        mainWebView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = false

            @SuppressLint("WebViewClientOnReceivedSslError")
            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                handler?.proceed()
            }
        }
        mainWebView.addJavascriptInterface(RouterBridge(), "AndroidBridge")
        rootContainer.addView(
            mainWebView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        setupLuciOverlay()

        mainWebView.loadUrl("file:///android_asset/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (luciOverlay.visibility == View.VISIBLE) {
                    handleLuciOverlayBack()
                } else {
                    mainWebView.evaluateJavascript("if(window.handleAppBack){window.handleAppBack();}", null)
                }
            }
        })
    }

    private fun handleLuciOverlayBack() {
        val currentUrl = (luciWebView.url ?: "").trimEnd('/')
        val entryClean = luciEntryUrl.trimEnd('/')
        if (currentUrl.isEmpty() || currentUrl == "about:blank" || currentUrl == entryClean) {
            closeLuciOverlay()
            return
        }
        val list = luciWebView.copyBackForwardList()
        if (list.currentIndex > 0) {
            val prevUrl = list.getItemAtIndex(list.currentIndex - 1)?.url ?: ""
            if (prevUrl.isEmpty() || prevUrl == "about:blank") {
                closeLuciOverlay()
                return
            }
            luciWebView.goBack()
        } else {
            closeLuciOverlay()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Suppress("DEPRECATION")
    private fun configureWebView(wv: WebView, forceDarkPage: Boolean) {
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.builtInZoomControls = true
        s.displayZoomControls = false

        if (forceDarkPage) {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
                WebSettingsCompat.setAlgorithmicDarkeningAllowed(s, true)
            }
            if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
                WebSettingsCompat.setForceDark(s, WebSettings.FORCE_DARK_ON)
            }
            if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK_STRATEGY)) {
                WebSettingsCompat.setForceDarkStrategy(
                    s,
                    WebSettingsCompat.DARK_STRATEGY_WEB_THEME_DARKENING_ONLY
                )
            }
        }
        wv.webChromeClient = WebChromeClient()
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    private fun createTabIconDrawable(tabKey: String, colorInt: Int): BitmapDrawable {
        val sizePx = dp(21)
        val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val scale = sizePx / 24f
        canvas.scale(scale, scale)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = colorInt
            style = Paint.Style.STROKE
            strokeWidth = 2f
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }

        when (tabKey) {
            "overview" -> {
                canvas.drawRoundRect(RectF(3f, 3f, 10f, 10f), 1.5f, 1.5f, paint)
                canvas.drawRoundRect(RectF(14f, 3f, 21f, 10f), 1.5f, 1.5f, paint)
                canvas.drawRoundRect(RectF(3f, 14f, 10f, 21f), 1.5f, 1.5f, paint)
                canvas.drawRoundRect(RectF(14f, 14f, 21f, 21f), 1.5f, 1.5f, paint)
            }
            "services" -> {
                val p1 = Path().apply {
                    moveTo(12f, 2f); lineTo(2f, 7f); lineTo(12f, 12f); lineTo(22f, 7f); close()
                }
                val p2 = Path().apply {
                    moveTo(2f, 12f); lineTo(12f, 17f); lineTo(22f, 12f)
                }
                val p3 = Path().apply {
                    moveTo(2f, 17f); lineTo(12f, 22f); lineTo(22f, 17f)
                }
                canvas.drawPath(p1, paint)
                canvas.drawPath(p2, paint)
                canvas.drawPath(p3, paint)
            }
            "clients" -> {
                val p1 = Path().apply {
                    moveTo(17f, 21f); lineTo(17f, 19f)
                    arcTo(RectF(9f, 15f, 17f, 23f), 0f, -90f, false)
                    lineTo(5f, 15f)
                    arcTo(RectF(1f, 15f, 9f, 23f), -90f, -90f, false)
                    lineTo(1f, 21f)
                }
                canvas.drawPath(p1, paint)
                canvas.drawCircle(9f, 7f, 4f, paint)
                val p2 = Path().apply {
                    moveTo(23f, 21f); lineTo(23f, 19f)
                    arcTo(RectF(15f, 15f, 23f, 23f), 0f, -65f, false)
                }
                val p3 = Path().apply {
                    arcTo(RectF(12f, 3f, 20f, 11f), -65f, 130f, false)
                }
                canvas.drawPath(p2, paint)
                canvas.drawPath(p3, paint)
            }
            "terminal" -> {
                val p1 = Path().apply {
                    moveTo(4f, 17f); lineTo(10f, 11f); lineTo(4f, 5f)
                }
                canvas.drawPath(p1, paint)
                canvas.drawLine(12f, 19f, 20f, 19f, paint)
            }
            "more" -> {
                canvas.drawCircle(12f, 5f, 1.5f, paint)
                canvas.drawCircle(12f, 12f, 1.5f, paint)
                canvas.drawCircle(12f, 19f, 1.5f, paint)
            }
        }
        return BitmapDrawable(resources, bmp)
    }

    private fun applyLuciDarkTheme(view: WebView?) {
        view?.evaluateJavascript("(function(){if(document.documentElement){document.documentElement.setAttribute('data-darkmode','true');}var css='html,body{background:#000000!important;background-color:#000000!important;color:#ffffff!important;color-scheme:dark!important;margin:0!important;padding:0!important;}'+'header,.navbar,#modemenu,.nav,.cbi-navigation,.cbi-navigation-step,footer,.footer{display:none!important;height:0!important;overflow:hidden!important;}'+'#maincontent,.main,.main-right,.container{background:#000000!important;background-color:#000000!important;padding:10px 12px 28px!important;margin:0!important;max-width:100%!important;}'+'h1,h2,h3,h4,legend{color:#4ce5b6!important;font-weight:800!important;}'+'a{color:#4ce5b6!important;}'+'.cbi-page-actions{padding:12px!important;margin-top:12px!important;background:#0d1117!important;border-radius:14px!important;display:flex!important;flex-wrap:wrap!important;gap:8px!important;align-items:center!important;}'+'.cbi-page-actions .cbi-button-apply,.cbi-page-actions button.important{flex:1 1 100%!important;height:42px!important;min-height:42px!important;max-height:42px!important;background:#4ce5b6!important;color:#000000!important;font-weight:800!important;border:none!important;border-radius:10px!important;}'+'.cbi-page-actions .cbi-button-save,.cbi-page-actions .cbi-button-reset{flex:1 1 calc(50% - 4px)!important;height:42px!important;min-height:42px!important;max-height:42px!important;border:none!important;border-radius:10px!important;font-weight:700!important;}'+'.cbi-page-actions .cbi-button-save{background:#1c2533!important;color:#4ce5b6!important;}'+'.cbi-page-actions .cbi-button-reset{background:rgba(255,92,92,0.2)!important;color:#ff6b6b!important;}';var st=document.getElementById('__owrt_force_dark');if(!st){st=document.createElement('style');st.id='__owrt_force_dark';(document.head||document.documentElement).appendChild(st);}if(st.textContent!==css){st.textContent=css;}var hdrs=document.querySelectorAll('header,.navbar,footer,.footer');for(var h=0;h<hdrs.length;h++){hdrs[h].style.setProperty('display','none','important');}var allUls=document.querySelectorAll('ul');for(var u=0;u<allUls.length;u++){var txt=allUls[u].textContent||'';if(txt.indexOf('Статус')!==-1&&txt.indexOf('Система')!==-1&&txt.indexOf('Службы')!==-1){allUls[u].style.setProperty('display','none','important');if(allUls[u].parentElement&&allUls[u].parentElement.tagName!=='BODY'){allUls[u].parentElement.style.setProperty('display','none','important');}}}var divs=document.querySelectorAll('div,p,span,a');for(var d=0;d<divs.length;d++){var t=(divs[d].textContent||'').trim();if((t.indexOf('Powered by LuCI')!==-1&&divs[d].children.length<=3)||(t==='Выйти'&&divs[d].children.length===0)){divs[d].style.setProperty('display','none','important');}}if(!window.__owrtDarkAttrObs&&document.documentElement){window.__owrtDarkAttrObs=new MutationObserver(function(){if(document.documentElement.getAttribute('data-darkmode')!=='true'){document.documentElement.setAttribute('data-darkmode','true');}});window.__owrtDarkAttrObs.observe(document.documentElement,{attributes:true,attributeFilter:['data-darkmode']});}})();", null)
    }

    private fun updateOverlayNavHighlight(activeTab: String) {
        val activeColor = Color.parseColor("#4CE5B6")
        val inactiveColor = Color.parseColor("#CBD5E1")
        overlayNavItems.forEach { (key, pair) ->
            val color = if (key == activeTab) activeColor else inactiveColor
            pair.first.setImageDrawable(createTabIconDrawable(key, color))
            pair.second.setTextColor(color)
        }
    }

    private fun switchToTabFromOverlay(tabName: String) {
        closeLuciOverlay()
        mainWebView.evaluateJavascript("if(window.switchTab){window.switchTab('$tabName');}", null)
    }

    private fun setupLuciOverlay() {
        luciOverlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            visibility = View.GONE
        }

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#080B0F"))
            setPadding(dp(14), dp(10), dp(14), dp(10))
            gravity = Gravity.CENTER_VERTICAL
        }

        luciTitleView = TextView(this).apply {
            text = "Панель LuCI"
            setTextColor(Color.parseColor("#4CE5B6"))
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(10)
            }
        }

        val closeBg = GradientDrawable().apply {
            setColor(Color.parseColor("#2A1418"))
            cornerRadius = dp(10).toFloat()
        }

        val closeBtn = TextView(this).apply {
            text = "Закрыть"
            setTextColor(Color.parseColor("#FF5C5C"))
            background = closeBg
            textSize = 13f
            setTypeface(null, Typeface.BOLD)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setOnClickListener { closeLuciOverlay() }
        }

        topBar.addView(luciTitleView)
        topBar.addView(closeBtn)

        luciWebView = WebView(this)
        luciWebView.setBackgroundColor(Color.BLACK)
        configureWebView(luciWebView, forceDarkPage = true)
        luciWebView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = false

            @SuppressLint("WebViewClientOnReceivedSslError")
            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                handler?.proceed()
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                applyLuciDarkTheme(view)
            }

            override fun onPageCommitVisible(view: WebView?, url: String?) {
                super.onPageCommitVisible(view, url)
                applyLuciDarkTheme(view)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                applyLuciDarkTheme(view)
                view?.postDelayed({ applyLuciDarkTheme(view) }, 300)
                view?.postDelayed({ applyLuciDarkTheme(view) }, 900)

                val uEsc = JSONObject.quote(luciUser)
                val pEsc = JSONObject.quote(luciPass)
                val autoLoginJs = """
                    (function() {
                        var inputs = document.getElementsByTagName('input');
                        var u = null, p = null;
                        for (var i = 0; i < inputs.length; i++) {
                            if (inputs[i].name === 'luci_username') u = inputs[i];
                            if (inputs[i].name === 'luci_password') p = inputs[i];
                        }
                        if (u && p && !window.__luciSubmitted) {
                            window.__luciSubmitted = true;
                            u.value = $uEsc;
                            p.value = $pEsc;
                            var f = p.closest('form');
                            if (f) f.submit();
                        }
                    })();
                """.trimIndent()
                view?.evaluateJavascript(autoLoginJs, null)
            }
        }

        val bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#080B0F"))
            setPadding(dp(4), dp(8), dp(4), dp(12))
            weightSum = 5f
        }

        val tabs = listOf(
            "Обзор" to "overview",
            "Сервисы" to "services",
            "Клиенты" to "clients",
            "Терминал" to "terminal",
            "Ещё" to "more"
        )

        overlayNavItems.clear()
        val defaultColor = Color.parseColor("#CBD5E1")
        tabs.forEach { (label, tabKey) ->
            val itemContainer = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(1), dp(4), dp(1), dp(4))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { switchToTabFromOverlay(tabKey) }
            }

            val iconView = ImageView(this).apply {
                setImageDrawable(createTabIconDrawable(tabKey, defaultColor))
                layoutParams = LinearLayout.LayoutParams(dp(21), dp(21)).apply {
                    bottomMargin = dp(4)
                }
            }

            val labelView = TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                textSize = 11f
                setTypeface(null, Typeface.BOLD)
                setTextColor(defaultColor)
                maxLines = 1
            }

            itemContainer.addView(iconView)
            itemContainer.addView(labelView)
            overlayNavItems[tabKey] = Pair(iconView, labelView)
            bottomBar.addView(itemContainer)
        }

        luciOverlay.addView(
            topBar,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        luciOverlay.addView(
            luciWebView,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        luciOverlay.addView(
            bottomBar,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        rootContainer.addView(
            luciOverlay,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
    }

    private fun closeLuciOverlay() {
        luciEntryUrl = ""
        luciOverlay.visibility = View.GONE
        luciWebView.stopLoading()
        luciWebView.clearHistory()
        luciWebView.loadUrl("about:blank")
    }

    private fun trustAllCertificates() {
        try {
            val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
                override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}
                override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
                override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
            })
            val sc = SSLContext.getInstance("TLS")
            sc.init(null, trustAllCerts, SecureRandom())
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.socketFactory)
            HttpsURLConnection.setDefaultHostnameVerifier { _, _ -> true }
        } catch (_: Exception) {
        }
    }

    inner class RouterBridge {

        @JavascriptInterface
        fun exitApp() {
            scope.launch(Dispatchers.Main) {
                finish()
            }
        }

        @JavascriptInterface
        fun openLuci(fullUrl: String, title: String, user: String, pass: String, sourceTab: String) {
            scope.launch(Dispatchers.Main) {
                luciUser = user
                luciPass = pass
                luciEntryUrl = fullUrl
                luciTitleView.text = title
                updateOverlayNavHighlight(sourceTab)
                luciWebView.clearHistory()
                luciOverlay.visibility = View.VISIBLE
                luciWebView.loadUrl(fullUrl)
            }
        }

        @JavascriptInterface
        fun ubusCall(callbackId: String, routerUrl: String, payloadJson: String) {
            scope.launch(Dispatchers.IO) {
                val responseJson = JSONObject()
                try {
                    val cleanBase = routerUrl.trim().trimEnd('/')
                    val endpoint = "$cleanBase/ubus"
                    val url = URL(endpoint)
                    val conn = url.openConnection() as HttpURLConnection
                    conn.requestMethod = "POST"
                    conn.connectTimeout = 7000
                    conn.readTimeout = 10000
                    conn.doOutput = true
                    conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")

                    OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
                        writer.write(payloadJson)
                    }

                    val code = conn.responseCode
                    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                    val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""

                    responseJson.put("ok", code in 200..299)
                    responseJson.put("code", code)
                    responseJson.put("body", body)
                } catch (e: Exception) {
                    responseJson.put("ok", false)
                    responseJson.put("error", e.message ?: "Ошибка сети")
                }

                val js = "window.__onNativeCallback('$callbackId', ${JSONObject.quote(responseJson.toString())});"
                scope.launch(Dispatchers.Main) {
                    mainWebView.evaluateJavascript(js, null)
                }
            }
        }

        @JavascriptInterface
        fun sshExec(callbackId: String, routerUrl: String, sshPort: Int, user: String, pass: String, command: String) {
            scope.launch {
                val host = extractHost(routerUrl)
                val res = sshManager.execCommand(host, sshPort, user, pass, command)
                val json = JSONObject()
                if (res.isSuccess) {
                    json.put("ok", true)
                    json.put("output", res.getOrDefault(""))
                } else {
                    json.put("ok", false)
                    json.put("error", res.exceptionOrNull()?.message ?: "Ошибка SSH")
                }
                val js = "window.__onNativeCallback('$callbackId', ${JSONObject.quote(json.toString())});"
                mainWebView.evaluateJavascript(js, null)
            }
        }

        private fun extractHost(rawUrl: String): String {
            return try {
                val normalized = if (rawUrl.startsWith("http://") || rawUrl.startsWith("https://")) rawUrl else "http://$rawUrl"
                URI(normalized).host ?: rawUrl.replace("http://", "").replace("https://", "").split(":")[0].split("/")[0]
            } catch (_: Exception) {
                rawUrl.replace("http://", "").replace("https://", "").split(":")[0].split("/")[0]
            }
        }
    }
}
