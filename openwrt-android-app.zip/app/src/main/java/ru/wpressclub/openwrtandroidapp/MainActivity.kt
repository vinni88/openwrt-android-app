package ru.wpressclub.openwrtandroidapp

import android.annotation.SuppressLint
import android.net.http.SslError
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView
    private val sshManager = SshManager()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        trustAllCertificates()

        webView = WebView(this)
        setContentView(webView)

        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        settings.useWideViewPort = true
        settings.loadWithOverviewMode = true
        settings.builtInZoomControls = false

        webView.webChromeClient = WebChromeClient()
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                return false
            }

            @SuppressLint("WebViewClientOnReceivedSslError")
            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                handler?.proceed()
            }
        }

        webView.addJavascriptInterface(RouterBridge(), "AndroidBridge")
        webView.loadUrl("file:///android_asset/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                webView.evaluateJavascript("if(window.handleAndroidBack){window.handleAndroidBack();}", null)
            }
        })
    }

    private fun trustAllCertificates() {
        try {
            val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
                override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}
                override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
                override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
            })
            val sc = SSLContext.getInstance("TLS")
            sc.init(null, trustAllCerts, SecureRandom())
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.socketFactory)
            HttpsURLConnection.setDefaultHostnameVerifier { _, _ -> true }
        } catch (_: Exception) {
        }
    }

    inner class RouterBridge {

        @JavascriptInterface
        fun ubusCall(callbackId: String, routerUrl: String, payloadJson: String) {
            scope.launch(Dispatchers.IO) {
                val responseJson = JSONObject()
                try {
                    val cleanBase = routerUrl.trim().trimEnd('/')
                    val endpoint = "$cleanBase/ubus"
                    val url = URL(endpoint)
                    val conn = url.openConnection() as HttpURLConnection
                    conn.requestMethod = "POST"
                    conn.connectTimeout = 7000
                    conn.readTimeout = 10000
                    conn.doOutput = true
                    conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")

                    OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
                        writer.write(payloadJson)
                    }

                    val code = conn.responseCode
                    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                    val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""

                    responseJson.put("ok", code in 200..299)
                    responseJson.put("code", code)
                    responseJson.put("body", body)
                } catch (e: Exception) {
                    responseJson.put("ok", false)
                    responseJson.put("error", e.message ?: "Ошибка сети")
                }

                val js = "window.__onNativeCallback('$callbackId', ${JSONObject.quote(responseJson.toString())});"
                scope.launch(Dispatchers.Main) {
                    webView.evaluateJavascript(js, null)
                }
            }
        }

        @JavascriptInterface
        fun sshExec(callbackId: String, routerUrl: String, sshPort: Int, user: String, pass: String, command: String) {
            scope.launch {
                val host = extractHost(routerUrl)
                val res = sshManager.execCommand(host, sshPort, user, pass, command)
                val json = JSONObject()
                if (res.isSuccess) {
                    json.put("ok", true)
                    json.put("output", res.getOrDefault(""))
                } else {
                    json.put("ok", false)
                    json.put("error", res.exceptionOrNull()?.message ?: "Ошибка SSH")
                }
                val js = "window.__onNativeCallback('$callbackId', ${JSONObject.quote(json.toString())});"
                webView.evaluateJavascript(js, null)
            }
        }

        private fun extractHost(rawUrl: String): String {
            return try {
                val normalized = if (rawUrl.startsWith("http://") || rawUrl.startsWith("https://")) rawUrl else "http://$rawUrl"
                URI(normalized).host ?: rawUrl.replace("http://", "").replace("https://", "").split(":")[0].split("/")[0]
            } catch (_: Exception) {
                rawUrl.replace("http://", "").replace("https://", "").split(":")[0].split("/")[0]
            }
        }
    }
}
