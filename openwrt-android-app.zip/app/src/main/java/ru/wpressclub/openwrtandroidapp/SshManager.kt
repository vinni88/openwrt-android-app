package ru.wpressclub.openwrtandroidapp

import com.jcraft.jsch.ChannelExec
import com.jcraft.jsch.JSch
import com.jcraft.jsch.Session
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.util.Properties

class SshManager {

    suspend fun execCommand(
        host: String,
        port: Int,
        user: String,
        pass: String,
        command: String,
        timeoutMs: Int = 10000
    ): Result<String> = withContext(Dispatchers.IO) {
        var session: Session? = null
        var channel: ChannelExec? = null
        try {
            val jsch = JSch()
            session = jsch.getSession(user, host, port)
            session.setPassword(pass)

            val config = Properties()
            config["StrictHostKeyChecking"] = "no"
            config["PreferredAuthentications"] = "password,keyboard-interactive"
            session.setConfig(config)
            session.connect(timeoutMs)

            channel = session.openChannel("exec") as ChannelExec
            channel.setCommand(command)

            val outputStream = ByteArrayOutputStream()
            val errorStream = ByteArrayOutputStream()
            channel.outputStream = outputStream
            channel.setErrStream(errorStream)
            channel.connect(timeoutMs)

            while (!channel.isClosed) {
                Thread.sleep(50)
            }

            val out = outputStream.toString("UTF-8")
            val err = errorStream.toString("UTF-8")
            val combined = if (err.isNotBlank() && out.isBlank()) err else if (err.isNotBlank()) "$out\n$err" else out
            Result.success(combined.trim())
        } catch (e: Exception) {
            Result.failure(e)
        } finally {
            try { channel?.disconnect() } catch (_: Exception) {}
            try { session?.disconnect() } catch (_: Exception) {}
        }
    }
}
