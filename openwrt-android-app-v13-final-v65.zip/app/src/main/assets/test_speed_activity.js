(function() {
  if (window.__TestSpeedActivityReady) return;
  window.__TestSpeedActivityReady = true;

  var running = false;
  var animTimer = null;
  var currentVal = 0;
  var targetVal = 0;
  var accentColor = '#4ce5b6';

  var SERVERS = {
    yandex: {
      name: 'Яндекс CDN (Россия · Москва)',
      pingHost: '77.88.8.8',
      dlUrls: [
        'http://mirror.yandex.ru/ubuntu-releases/24.04.2/ubuntu-24.04.2-live-server-amd64.iso',
        'http://mirror.yandex.ru/debian/ls-lR.gz'
      ],
      ulUrl: 'http://speedtest.selectel.ru/'
    },
    selectel: {
      name: 'Selectel (Россия · Санкт-Петербург)',
      pingHost: '188.93.16.19',
      dlUrls: [
        'http://speedtest.selectel.ru/100MB',
        'http://speedtest.selectel.ru/10MB'
      ],
      ulUrl: 'http://speedtest.selectel.ru/'
    },
    megafon: {
      name: 'МегаФон (Россия)',
      pingHost: '193.232.248.45',
      dlUrls: [
        'http://spb.speedtest.megafon.ru:8080/speedtest/random4000x4000.jpg',
        'http://speedtest.selectel.ru/100MB'
      ],
      ulUrl: 'http://spb.speedtest.megafon.ru:8080/speedtest/upload.php'
    },
    tele2: {
      name: 'Tele2 / T2 (Россия)',
      pingHost: '193.124.212.1',
      dlUrls: [
        'http://spb.speedtest.tele2.ru:8080/speedtest/random4000x4000.jpg',
        'http://speedtest.selectel.ru/100MB'
      ],
      ulUrl: 'http://spb.speedtest.tele2.ru:8080/speedtest/upload.php'
    },
    beeline: {
      name: 'Билайн (Россия)',
      pingHost: '212.119.240.1',
      dlUrls: [
        'http://spb.speedtest.beeline.ru:8080/speedtest/random4000x4000.jpg',
        'http://speedtest.selectel.ru/100MB'
      ],
      ulUrl: 'http://spb.speedtest.beeline.ru:8080/speedtest/upload.php'
    },
    mts: {
      name: 'МТС (Россия)',
      pingHost: '213.87.0.1',
      dlUrls: [
        'http://spb.speedtest.mts.ru:8080/speedtest/random4000x4000.jpg',
        'http://speedtest.selectel.ru/100MB'
      ],
      ulUrl: 'http://spb.speedtest.mts.ru:8080/speedtest/upload.php'
    },
    rostelecom: {
      name: 'Ростелеком (Россия)',
      pingHost: '212.188.0.1',
      dlUrls: [
        'http://spb.speedtest.rt.ru:8080/speedtest/random4000x4000.jpg',
        'http://speedtest.selectel.ru/100MB'
      ],
      ulUrl: 'http://spb.speedtest.rt.ru:8080/speedtest/upload.php'
    },
    domru: {
      name: 'Дом.ru (Россия)',
      pingHost: '89.189.160.1',
      dlUrls: [
        'http://speedtest.spb.domru.ru:8080/speedtest/random4000x4000.jpg',
        'http://speedtest.selectel.ru/100MB'
      ],
      ulUrl: 'http://speedtest.spb.domru.ru:8080/speedtest/upload.php'
    },
    skynet: {
      name: 'SkyNet (Россия · Санкт-Петербург)',
      pingHost: '80.64.80.1',
      dlUrls: [
        'http://speedtest.sknt.ru:8080/speedtest/random4000x4000.jpg',
        'http://speedtest.selectel.ru/100MB'
      ],
      ulUrl: 'http://speedtest.sknt.ru:8080/speedtest/upload.php'
    }
  };

  function initDom() {
    var host = document.getElementById('tab-test');
    if (!host || document.getElementById('sp-start-circle')) return;
    host.innerHTML =
      '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px;">' +
        '<div class="metric-box" style="margin:0;padding:12px 14px;">' +
          '<div class="metric-label"><span style="color:#4ce5b6;font-weight:900;">↓</span> СКАЧАТЬ</div>' +
          '<div style="display:flex;align-items:baseline;gap:6px;">' +
            '<div class="metric-value" id="sp-dl-val" style="font-size:22px;">—</div>' +
            '<span style="font-size:12px;color:#94a3b8;font-weight:700;">Мбит/с</span>' +
          '</div>' +
        '</div>' +
        '<div class="metric-box" style="margin:0;padding:12px 14px;">' +
          '<div class="metric-label"><span style="color:#ffb84d;font-weight:900;">↑</span> ЗАГРУЗИТЬ</div>' +
          '<div style="display:flex;align-items:baseline;gap:6px;">' +
            '<div class="metric-value" id="sp-ul-val" style="font-size:22px;">—</div>' +
            '<span style="font-size:12px;color:#94a3b8;font-weight:700;" id="sp-ul-unit">Мбит/с</span>' +
          '</div>' +
        '</div>' +
      '</div>' +
      '<div style="display:flex;justify-content:space-around;align-items:center;background:var(--surface);border-radius:14px;padding:10px 12px;margin-bottom:14px;font-size:13px;">' +
        '<div><span style="color:#94a3b8;font-weight:700;">Ping</span> <span id="sp-ping-val" style="color:#fff;font-weight:800;">—</span> <span style="color:#94a3b8;font-size:12px;">мс</span></div>' +
        '<div style="width:1px;height:16px;background:rgba(255,255,255,0.1);"></div>' +
        '<div><span style="color:#94a3b8;font-weight:700;">Jitter</span> <span id="sp-jitter-val" style="color:#fff;font-weight:800;">—</span> <span style="color:#94a3b8;font-size:12px;">мс</span></div>' +
        '<div style="width:1px;height:16px;background:rgba(255,255,255,0.1);"></div>' +
        '<span class="badge badge-up" id="sp-status" style="margin:0;">Готов</span>' +
      '</div>' +
      '<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;padding:6px 0 12px;min-height:236px;">' +
        '<div id="sp-circle-wrap" style="display:flex;align-items:center;justify-content:center;height:236px;">' +
          '<button type="button" id="sp-start-circle" onclick="window.TestSpeedActivity.start()" style="width:184px;height:184px;border-radius:50%;background:#070b10;border:4px solid #4ce5b6;box-shadow:0 0 24px rgba(76,229,182,0.22);color:#fff;font-size:24px;font-weight:800;cursor:pointer;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;">' +
            '<span id="sp-circle-text">Начать</span>' +
            '<span style="font-size:11px;font-weight:700;color:#4ce5b6;text-transform:uppercase;">Тест с роутера</span>' +
          '</button>' +
        '</div>' +
        '<div id="sp-gauge-wrap" class="hidden" style="position:relative;width:260px;height:236px;display:flex;align-items:center;justify-content:center;">' +
          '<canvas id="sp-gauge-canvas" width="520" height="472" style="width:260px;height:236px;display:block;"></canvas>' +
          '<div style="position:absolute;top:88px;left:48px;right:48px;text-align:center;pointer-events:none;">' +
            '<div id="sp-gauge-phase" style="font-size:10.5px;font-weight:800;color:#4ce5b6;text-transform:uppercase;margin-bottom:4px;">ВХОДЯЩАЯ</div>' +
            '<div id="sp-gauge-num" style="font-size:34px;font-weight:900;color:#fff;line-height:1.05;">0.00</div>' +
            '<div style="font-size:12px;font-weight:700;color:#94a3b8;margin-top:3px;">Мбит/с</div>' +
          '</div>' +
        '</div>' +
      '</div>' +
      '<div class="card" style="padding:14px;">' +
        '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">' +
          '<span style="font-size:12px;font-weight:800;color:#4ce5b6;text-transform:uppercase;">Сервер тестирования (РФ)</span>' +
          '<span style="font-size:11.5px;color:#94a3b8;">SSH с роутера</span>' +
        '</div>' +
        '<select id="sp-server-select" onchange="window.TestSpeedActivity.onServerChange()" style="width:100%;background:#151c26;color:#fff;border:none;border-radius:11px;padding:11px 12px;font-size:14px;font-weight:700;outline:none;">' +
          '<option value="yandex">Яндекс CDN (Россия · Москва)</option>' +
          '<option value="selectel">Selectel (Россия · Санкт-Петербург)</option>' +
          '<option value="megafon">МегаФон (Россия)</option>' +
          '<option value="tele2">Tele2 / T2 (Россия)</option>' +
          '<option value="beeline">Билайн (Россия)</option>' +
          '<option value="mts">МТС (Россия)</option>' +
          '<option value="rostelecom">Ростелеком (Россия)</option>' +
          '<option value="domru">Дом.ru (Россия)</option>' +
          '<option value="skynet">SkyNet (Россия · Санкт-Петербург)</option>' +
          '<option value="custom">Свой URL сервера...</option>' +
        '</select>' +
        '<div id="sp-custom-wrap" class="hidden" style="margin-top:8px;">' +
          '<input id="sp-custom-url" type="url" placeholder="http://speedtest.example.com/100MB.bin" style="font-size:14px;padding:11px 12px;">' +
        '</div>' +
        '<div id="sp-error" class="error-banner hidden"></div>' +
      '</div>';
  }

  function ratioForMbps(mbps) {
    var stops = [0, 5, 10, 50, 100, 250, 500, 1000];
    if (mbps <= 0) return 0;
    if (mbps >= 1000) return 1;
    for (var i = 0; i < stops.length - 1; i++) {
      if (mbps <= stops[i + 1]) {
        return (i + (mbps - stops[i]) / (stops[i + 1] - stops[i])) / (stops.length - 1);
      }
    }
    return 1;
  }

  function renderGauge(val, col) {
    var canvas = document.getElementById('sp-gauge-canvas');
    if (!canvas) return;
    var ctx = canvas.getContext('2d');
    var w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    var cx = w / 2, cy = h * 0.52, rOut = 215, rIn = 158;
    var a0 = 135 * Math.PI / 180, a1 = 405 * Math.PI / 180, span = a1 - a0;

    ctx.lineCap = 'round';
    ctx.lineWidth = 22;
    ctx.strokeStyle = '#151c26';
    ctx.beginPath();
    ctx.arc(cx, cy, rOut, a0, a1);
    ctx.stroke();

    var ratio = ratioForMbps(val);
    if (ratio > 0.002) {
      ctx.strokeStyle = col;
      ctx.beginPath();
      ctx.arc(cx, cy, rOut, a0, a0 + span * ratio);
      ctx.stroke();
    }

    var ang = a0 + span * ratio;
    ctx.strokeStyle = '#ffffff';
    ctx.lineWidth = 7;
    ctx.beginPath();
    ctx.moveTo(cx + Math.cos(ang) * rIn, cy + Math.sin(ang) * rIn);
    ctx.lineTo(cx + Math.cos(ang) * (rOut - 16), cy + Math.sin(ang) * (rOut - 16));
    ctx.stroke();
  }

  function startAnim() {
    stopAnim();
    animTimer = setInterval(function() {
      currentVal += (targetVal - currentVal) * 0.28;
      if (Math.abs(targetVal - currentVal) < 0.02) currentVal = targetVal;
      renderGauge(currentVal, accentColor);
      var num = document.getElementById('sp-gauge-num');
      if (num) num.textContent = currentVal.toFixed(2);
    }, 40);
  }

  function stopAnim() {
    if (animTimer) {
      clearInterval(animTimer);
      animTimer = null;
    }
  }

  function finishGaugeToCircle(btnLabel) {
    stopAnim();
    var g = document.getElementById('sp-gauge-wrap');
    var c = document.getElementById('sp-circle-wrap');
    var t = document.getElementById('sp-circle-text');
    if (g) g.classList.add('hidden');
    if (c) c.classList.remove('hidden');
    if (t && btnLabel) t.textContent = btnLabel;
  }

  function shQuote(s) {
    return "'" + String(s).replace(/'/g, "'\\''") + "'";
  }

  async function runSpeedTest() {
    if (running) return;
    running = true;
    initDom();

    var sel = document.getElementById('sp-server-select');
    var key = sel ? sel.value : 'yandex';
    var pingHost = '77.88.8.8';
    var dlUrls = [];
    var ulUrl = '';

    if (key === 'custom') {
      var rawUrl = ((document.getElementById('sp-custom-url') || {}).value || '').trim();
      if (!rawUrl) {
        running = false;
        var err1 = document.getElementById('sp-error');
        if (err1) { err1.textContent = 'Укажите URL сервера'; err1.classList.remove('hidden'); }
        return;
      }
      dlUrls = [rawUrl];
      ulUrl = rawUrl;
      try { pingHost = new URL(rawUrl.indexOf('http') === 0 ? rawUrl : 'http://' + rawUrl).hostname; } catch (_) {}
    } else {
      var srv = SERVERS[key] || SERVERS.yandex;
      pingHost = srv.pingHost;
      dlUrls = srv.dlUrls;
      ulUrl = srv.ulUrl;
    }

    var cWrap = document.getElementById('sp-circle-wrap');
    var gWrap = document.getElementById('sp-gauge-wrap');
    var phase = document.getElementById('sp-gauge-phase');
    var badge = document.getElementById('sp-status');
    var errEl = document.getElementById('sp-error');
    var dlOut = document.getElementById('sp-dl-val');
    var ulOut = document.getElementById('sp-ul-val');
    var ulUnit = document.getElementById('sp-ul-unit');
    var pingOut = document.getElementById('sp-ping-val');
    var jitOut = document.getElementById('sp-jitter-val');

    if (errEl) { errEl.classList.add('hidden'); errEl.textContent = ''; }
    if (cWrap) cWrap.classList.add('hidden');
    if (gWrap) gWrap.classList.remove('hidden');
    if (dlOut) dlOut.textContent = '—';
    if (ulOut) ulOut.textContent = '—';
    if (ulUnit) ulUnit.textContent = 'Мбит/с';
    if (pingOut) pingOut.textContent = '—';
    if (jitOut) jitOut.textContent = '—';

    currentVal = 0;
    targetVal = 0;
    accentColor = '#4ce5b6';
    if (phase) { phase.textContent = 'PING'; phase.style.color = '#4ce5b6'; }
    if (badge) { badge.textContent = 'Ping...'; badge.className = 'badge badge-up'; }
    startAnim();

    try {
      var pingCmd = 'P_OUT=$(ping -c 5 -W 2 ' + shQuote(pingHost) + ' 2>/dev/null || ping -c 5 -W 2 77.88.8.8 2>/dev/null); ' +
        'RTT_LIST=$(echo "$P_OUT" | sed -n \'s/.*time=\([0-9.][0-9.]*\).*/\1/p\'); ' +
        'AVG_MS=$(echo "$P_OUT" | awk -F\'/\' \'/round-trip|rtt/ {print $5}\'); ' +
        'echo "RTT:$RTT_LIST"; echo "AVG:$AVG_MS"';
      var pRes = await callSsh(pingCmd);
      if (!pRes || !pRes.ok) throw new Error((pRes && pRes.error) || 'Нет SSH-соединения');

      var rttRaw = '', avgMs = '';
      (pRes.output || '').split('\n').forEach(function(line) {
        if (line.indexOf('RTT:') === 0) rttRaw = line.slice(4).trim();
        if (line.indexOf('AVG:') === 0) avgMs = line.slice(4).trim();
      });
      var rtts = rttRaw.split(/\s+/).map(Number).filter(function(n) { return !isNaN(n) && n >= 0; });
      if (avgMs && !isNaN(parseFloat(avgMs))) {
        if (pingOut) pingOut.textContent = parseFloat(avgMs).toFixed(1);
      } else if (rtts.length > 0) {
        var sum = rtts.reduce(function(a, b) { return a + b; }, 0);
        if (pingOut) pingOut.textContent = (sum / rtts.length).toFixed(1);
      }
      if (rtts.length >= 2) {
        var dSum = 0;
        for (var i = 1; i < rtts.length; i++) dSum += Math.abs(rtts[i] - rtts[i - 1]);
        if (jitOut) jitOut.textContent = (dSum / (rtts.length - 1)).toFixed(1);
      }

      if (phase) { phase.textContent = '1/2 · ВХОДЯЩАЯ'; phase.style.color = '#4ce5b6'; }
      if (badge) badge.textContent = 'Скачивание...';
      accentColor = '#4ce5b6';

      var urlsArg = dlUrls.map(shQuote).join(' ');
      var dlCmd = 'IFACE=$(ip route show default 2>/dev/null | awk \'/default/ {print $5; exit}\'); ' +
        '[ -z "$IFACE" ] && IFACE=$(awk -F: \'$1 !~ /lo/ {gsub(/^[[:space:]]+|[[:space:]]+$/, "", $1); print $1; exit}\' /proc/net/dev); ' +
        'get_rx(){ awk -v dev="$IFACE" -F"[: ]+" \'$0 ~ dev {for(i=1;i<=NF;i++) if($i==dev){print $(i+1); exit}}\' /proc/net/dev; }; ' +
        'get_sec(){ awk \'{print $1}\' /proc/uptime; }; ' +
        'PICKED=""; for U in ' + urlsArg + '; do ' +
        'if command -v curl >/dev/null 2>&1; then ' +
        'C=$(curl -s -L -o /dev/null --connect-timeout 3 --max-time 4 -r 0-65535 -w "%{http_code}" "$U" 2>/dev/null); ' +
        '[ "$C" = "200" ] || [ "$C" = "206" ] && { PICKED="$U"; break; }; ' +
        'elif command -v wget >/dev/null 2>&1; then ' +
        'wget -q -T 4 --spider "$U" 2>/dev/null && { PICKED="$U"; break; }; fi; done; ' +
        'if [ -z "$PICKED" ]; then echo "DL_NONE"; exit 0; fi; ' +
        'SB=$(get_rx); ST=$(get_sec); PB="$SB"; PT="$ST"; ' +
        'if command -v curl >/dev/null 2>&1; then ' +
        '(curl -s -L -o /dev/null --max-time 8 -w "S1:%{speed_download}\n" "$PICKED" 2>/dev/null & ' +
        'curl -s -L -o /dev/null --max-time 8 -w "S2:%{speed_download}\n" "$PICKED" 2>/dev/null & wait) > /tmp/sp_dl.out 2>/dev/null & PID=$!; ' +
        'else ' +
        '(wget -q -T 8 -O /dev/null "$PICKED" >/dev/null 2>&1) & PID=$!; fi; ' +
        'while kill -0 $PID 2>/dev/null; do sleep 0.5; CB=$(get_rx); CT=$(get_sec); ' +
        'echo "STEP_DL:$PB:$CB:$PT:$CT"; PB="$CB"; PT="$CT"; done; wait $PID 2>/dev/null; ' +
        'EB=$(get_rx); ET=$(get_sec); echo "TOTAL_DL:$SB:$EB:$ST:$ET"; ' +
        'cat /tmp/sp_dl.out 2>/dev/null; rm -f /tmp/sp_dl.out';

      var dlSamples = [];
      var curlSumBps = 0;
      var totalDlMbps = null;
      var dlRes = await callSsh(dlCmd);
      if (dlRes && dlRes.ok) {
        (dlRes.output || '').split('\n').forEach(function(line) {
          if (line.indexOf('STEP_DL:') === 0) {
            var p = line.slice(8).trim().split(':');
            var db = parseFloat(p[1]) - parseFloat(p[0]);
            var dt = parseFloat(p[3]) - parseFloat(p[2]);
            if (!isNaN(db) && !isNaN(dt) && db > 0 && dt > 0.05) {
              var mbps = (db * 8) / (dt * 1000000);
              if (mbps > 0.05) dlSamples.push(mbps);
            }
          } else if (line.indexOf('TOTAL_DL:') === 0) {
            var tp = line.slice(9).trim().split(':');
            var tdb = parseFloat(tp[1]) - parseFloat(tp[0]);
            var tdt = parseFloat(tp[3]) - parseFloat(tp[2]);
            if (!isNaN(tdb) && !isNaN(tdt) && tdb > 0 && tdt > 0.05) {
              totalDlMbps = (tdb * 8) / (tdt * 1000000);
            }
          } else if (line.indexOf('S1:') === 0 || line.indexOf('S2:') === 0) {
            var bps = parseFloat(line.slice(3).trim());
            if (!isNaN(bps) && bps > 0) curlSumBps += bps;
          }
        });
      }

      var finalDl = null;
      if (curlSumBps > 0) {
        finalDl = (curlSumBps * 8) / 1000000;
      } else if (dlSamples.length > 0) {
        finalDl = dlSamples.reduce(function(a, b) { return a + b; }, 0) / dlSamples.length;
      } else if (totalDlMbps !== null && totalDlMbps > 0) {
        finalDl = totalDlMbps;
      }

      if (finalDl !== null && finalDl > 0) {
        targetVal = finalDl;
        if (dlOut) dlOut.textContent = finalDl.toFixed(2);
      } else if (dlOut) {
        dlOut.textContent = 'Н/Д';
      }

      await new Promise(function(r) { setTimeout(r, 700); });

      currentVal = 0;
      targetVal = 0;
      accentColor = '#ffb84d';
      if (phase) { phase.textContent = '2/2 · ИСХОДЯЩАЯ'; phase.style.color = '#ffb84d'; }
      if (badge) badge.textContent = 'Отдача...';

      var ulCmd = 'if ! command -v curl >/dev/null 2>&1; then echo "UL_NOCURL"; exit 0; fi; ' +
        'SPD=$(dd if=/dev/zero bs=65536 count=256 2>/dev/null | curl -s -L -o /dev/null --max-time 10 -X POST --data-binary @- -w "%{speed_upload}" ' + shQuote(ulUrl) + ' 2>/dev/null); ' +
        'echo "CURL_UL:$SPD"';

      var ulMbps = null, noCurl = false;
      var uRes = await callSsh(ulCmd);
      if (uRes && uRes.ok) {
        (uRes.output || '').split('\n').forEach(function(line) {
          if (line.indexOf('CURL_UL:') === 0) {
            var bps = parseFloat(line.slice(8).trim());
            if (!isNaN(bps) && bps > 0) ulMbps = (bps * 8) / 1000000;
          } else if (line.indexOf('UL_NOCURL') === 0) {
            noCurl = true;
          }
        });
      }

      if (ulMbps !== null && ulMbps > 0) {
        targetVal = ulMbps;
        if (ulOut) ulOut.textContent = ulMbps.toFixed(2);
      } else if (ulOut) {
        ulOut.textContent = 'Н/Д';
        if (ulUnit && noCurl) ulUnit.textContent = 'нет curl';
      }

      await new Promise(function(r) { setTimeout(r, 700); });
      if (badge) { badge.textContent = 'Готово'; badge.className = 'badge badge-up'; }
      finishGaugeToCircle('Повторить');
    } catch (e) {
      if (errEl) { errEl.textContent = 'Ошибка: ' + (e && e.message ? e.message : e); errEl.classList.remove('hidden'); }
      if (badge) { badge.textContent = 'Ошибка'; badge.className = 'badge badge-down'; }
      finishGaugeToCircle('Повторить');
    } finally {
      running = false;
    }
  }

  window.TestSpeedActivity = {
    init: initDom,
    start: runSpeedTest,
    onServerChange: function() {
      var sel = document.getElementById('sp-server-select');
      var wrap = document.getElementById('sp-custom-wrap');
      if (sel && wrap) wrap.classList.toggle('hidden', sel.value !== 'custom');
    }
  };
})();
