package ru.wpressclub.openwrtandroidapp

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.net.http.SslError
import android.os.Bundle
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.CookieHandler
import java.net.CookieManager as NetCookieManager
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

class MainActivity : AppCompatActivity() {

    private lateinit var rootContainer: FrameLayout
    private lateinit var mainWebView: WebView
    private lateinit var luciOverlay: LinearLayout
    private lateinit var luciTitleView: TextView
    private lateinit var luciWebView: WebView
    private val overlayNavItems = mutableMapOf<String, Pair<ImageView, TextView>>()

    private val sshManager = SshManager()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var luciUser: String = "root"
    private var luciPass: String = ""
    private var luciEntryUrl: String = ""

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        super.onCreate(savedInstanceState)
        trustAllCertificates()

        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.parseColor("#080B0F")

        rootContainer = FrameLayout(this)
        rootContainer.setBackgroundColor(Color.BLACK)
        setContentView(rootContainer)

        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)

        mainWebView = WebView(this)
        mainWebView.setBackgroundColor(Color.BLACK)
        configureWebView(mainWebView, forceDarkPage = false)
        mainWebView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = false

            @SuppressLint("WebViewClientOnReceivedSslError")
            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                handler?.proceed()
            }
        }
        mainWebView.addJavascriptInterface(RouterBridge(), "AndroidBridge")
        rootContainer.addView(
            mainWebView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        setupLuciOverlay()

        mainWebView.loadUrl("file:///android_asset/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (luciOverlay.visibility == View.VISIBLE) {
                    handleLuciOverlayBack()
                } else {
                    mainWebView.evaluateJavascript("if(window.handleAppBack){window.handleAppBack();}", null)
                }
            }
        })
    }

    private fun handleLuciOverlayBack() {
        val currentUrl = (luciWebView.url ?: "").trimEnd('/')
        val entryClean = luciEntryUrl.trimEnd('/')
        if (currentUrl.isEmpty() || currentUrl == "about:blank" || currentUrl == entryClean) {
            closeLuciOverlay()
            return
        }
        val list = luciWebView.copyBackForwardList()
        if (list.currentIndex > 0) {
            val prevUrl = list.getItemAtIndex(list.currentIndex - 1)?.url ?: ""
            if (prevUrl.isEmpty() || prevUrl == "about:blank") {
                closeLuciOverlay()
                return
            }
            luciWebView.goBack()
        } else {
            closeLuciOverlay()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Suppress("DEPRECATION")
    private fun configureWebView(wv: WebView, forceDarkPage: Boolean) {
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.builtInZoomControls = true
        s.displayZoomControls = false

        if (forceDarkPage) {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
                WebSettingsCompat.setAlgorithmicDarkeningAllowed(s, true)
            }
            if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
                WebSettingsCompat.setForceDark(s, WebSettings.FORCE_DARK_ON)
            }
            if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK_STRATEGY)) {
                WebSettingsCompat.setForceDarkStrategy(
                    s,
                    WebSettingsCompat.DARK_STRATEGY_PREFER_WEB_THEME_OVER_USER_AGENT_DARKENING
                )
            }
        }
        wv.webChromeClient = WebChromeClient()
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    private fun createTabIconDrawable(tabKey: String, colorInt: Int): BitmapDrawable {
        val sizePx = dp(21)
        val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val scale = sizePx / 24f
        canvas.scale(scale, scale)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = colorInt
            style = Paint.Style.STROKE
            strokeWidth = 2f
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }

        when (tabKey) {
            "overview" -> {
                canvas.drawRoundRect(RectF(3f, 3f, 10f, 10f), 1.5f, 1.5f, paint)
                canvas.drawRoundRect(RectF(14f, 3f, 21f, 10f), 1.5f, 1.5f, paint)
                canvas.drawRoundRect(RectF(3f, 14f, 10f, 21f), 1.5f, 1.5f, paint)
                canvas.drawRoundRect(RectF(14f, 14f, 21f, 21f), 1.5f, 1.5f, paint)
            }
            "services" -> {
                val p1 = Path().apply {
                    moveTo(12f, 2f); lineTo(2f, 7f); lineTo(12f, 12f); lineTo(22f, 7f); close()
                }
                val p2 = Path().apply {
                    moveTo(2f, 12f); lineTo(12f, 17f); lineTo(22f, 12f)
                }
                val p3 = Path().apply {
                    moveTo(2f, 17f); lineTo(12f, 22f); lineTo(22f, 17f)
                }
                canvas.drawPath(p1, paint)
                canvas.drawPath(p2, paint)
                canvas.drawPath(p3, paint)
            }
            "clients" -> {
                val p1 = Path().apply {
                    moveTo(17f, 21f); lineTo(17f, 19f)
                    arcTo(RectF(9f, 15f, 17f, 23f), 0f, -90f, false)
                    lineTo(5f, 15f)
                    arcTo(RectF(1f, 15f, 9f, 23f), -90f, -90f, false)
                    lineTo(1f, 21f)
                }
                canvas.drawPath(p1, paint)
                canvas.drawCircle(9f, 7f, 4f, paint)
                val p2 = Path().apply {
                    moveTo(23f, 21f); lineTo(23f, 19f)
                    arcTo(RectF(15f, 15f, 23f, 23f), 0f, -65f, false)
                }
                val p3 = Path().apply {
                    arcTo(RectF(12f, 3f, 20f, 11f), -65f, 130f, false)
                }
                canvas.drawPath(p2, paint)
                canvas.drawPath(p3, paint)
            }
            "modem" -> {
                canvas.drawLine(4f, 20f, 4f, 15f, paint)
                canvas.drawLine(9f, 20f, 9f, 11f, paint)
                canvas.drawLine(14f, 20f, 14f, 7f, paint)
                canvas.drawLine(19f, 20f, 19f, 4f, paint)
            }
            "test" -> {
                canvas.drawLine(6f, 20f, 6f, 10f, paint)
                canvas.drawLine(12f, 20f, 12f, 14f, paint)
                canvas.drawLine(18f, 20f, 18f, 4f, paint)
            }
            "more" -> {
                canvas.drawCircle(12f, 5f, 1.5f, paint)
                canvas.drawCircle(12f, 12f, 1.5f, paint)
                canvas.drawCircle(12f, 19f, 1.5f, paint)
            }
        }
        return BitmapDrawable(resources, bmp)
    }

    private fun applyLuciDarkTheme(view: WebView?) {
        val js = """
            (function(){
                if(document.documentElement&&document.documentElement.hasAttribute('data-darkmode')){
                    document.documentElement.removeAttribute('data-darkmode');
                }
                var css = [
                    ':root{--background-color-delta-l-sign:1;--background-color-h:215;--background-color-s:28%;--background-color-l:8%;--text-color-delta-l-sign:-1;--text-color-h:0;--text-color-s:0%;--text-color-l:100%;--border-color-delta-l-sign:1;--primary-color-high:#4ce5b6;--primary-color-medium:#38b890;--primary-color-low:#268f6f;--on-primary-color:#000000;color-scheme:dark!important;}',
                    'html,body{background:#000000!important;background-color:#000000!important;background-image:none!important;color:#ffffff!important;color-scheme:dark!important;margin:0!important;padding:0!important;}',
                    'header,.navbar,#modemenu,.nav,.cbi-navigation,.cbi-navigation-step,footer,.footer{display:none!important;height:0!important;overflow:hidden!important;}',
                    '#maincontent,.main,.main-right,.container,#view{background:#000000!important;background-color:#000000!important;background-image:none!important;padding:14px 12px 28px!important;margin:0!important;max-width:100%!important;}',
                    '.cbi-map,.cbi-section,.cbi-section-node,.cbi-value,fieldset,.panel,.card,.alert-message,[data-tab]{background:#0d1117!important;background-color:#0d1117!important;background-image:none!important;color:#ffffff!important;border:none!important;box-shadow:none!important;border-radius:14px!important;}',
                    'table,tbody,thead,tfoot,tr,td,th,.table,.tr,.td,.th,.table-wrapper,.cbi-section-table,.cbi-section-table-row,.cbi-section-table-cell,.cbi-rowstyle-1,.cbi-rowstyle-2,.cbi-value-field,.table .tr,.table .td,.table .th,.cbi-section-table .tr,.cbi-section-table .td,.cbi-section-table .th{background:#0d1117!important;background-color:#0d1117!important;background-image:none!important;color:#ffffff!important;border:none!important;box-shadow:none!important;}',
                    '.ifacebox,.ifacebox-head,.ifacebox-body,.ifacebadge,span.ifacebadge,div.ifacebadge,.td .ifacebadge,.tr .ifacebadge,.table .td .ifacebadge,.cbi-value-field .ifacebadge,.port,.network-status-table,.wifi-status-table,[data-widget],.cbi-value-field>div,.cbi-section-table-cell>div{background:#151c26!important;background-color:#151c26!important;background-image:none!important;color:#ffffff!important;border:none!important;box-shadow:none!important;border-radius:12px!important;}',
                    '.ifacebox-head{background:#1c2533!important;background-color:#1c2533!important;background-image:none!important;padding:6px 8px!important;margin-bottom:6px!important;}',
                    '.ifacebox-head.active{background:#4ce5b6!important;background-color:#4ce5b6!important;color:#000000!important;}',
                    '.ifacebox-head.active *{color:#000000!important;}',
                    'h1,h2,h3,h4,legend{color:#4ce5b6!important;font-weight:800!important;border:none!important;}',
                    'label,.cbi-value-title,.cbi-value-description,.cbi-section-descr,p,span,div,td,th,.td,.th,li,strong,small{color:#ffffff!important;border-color:transparent!important;}',
                    'a{color:#4ce5b6!important;text-decoration:none!important;}',
                    '.tabs,.cbi-tabmenu,ul.tabs,ul.cbi-tabmenu{background:#0d1117!important;background-color:#0d1117!important;background-image:none!important;border:none!important;border-radius:14px!important;padding:6px!important;display:flex!important;flex-wrap:wrap!important;gap:6px!important;margin:0 0 12px 0!important;}',
                    '.tabs>li,.cbi-tabmenu>li,.cbi-tab,.cbi-tab-disabled{background:#151c26!important;background-color:#151c26!important;background-image:none!important;border:none!important;border-radius:10px!important;margin:0!important;padding:0!important;}',
                    '.tabs>li>a,.cbi-tabmenu>li>a,.cbi-tab>a,.cbi-tab-disabled>a{background:transparent!important;color:#ffffff!important;border:none!important;padding:8px 12px!important;display:block!important;font-weight:700!important;}',
                    '.tabs>li.active,.cbi-tabmenu>li.cbi-tab,li.cbi-tab{background:#4ce5b6!important;background-color:#4ce5b6!important;}',
                    '.tabs>li.active>a,.cbi-tabmenu>li.cbi-tab>a,li.cbi-tab>a{color:#000000!important;font-weight:800!important;}',
                    '.cbi-dynlist,.cbi-dynlist>.item,.cbi-dynlist>.add-item,.cbi-dynlist>.add-item>input,.cbi-dynlist>.add-item>span,.cbi-dynlist>.add-item>div{background:#151c26!important;background-color:#151c26!important;background-image:none!important;color:#ffffff!important;border:none!important;box-shadow:none!important;}',
                    'input,select,textarea,.cbi-input-text,.cbi-input-select{background:#151c26!important;background-color:#151c26!important;background-image:none!important;color:#ffffff!important;color-scheme:dark!important;border:none!important;border-radius:10px!important;padding:10px 12px!important;min-height:44px!important;height:auto!important;}',
                    'select option{background:#0d1117!important;background-color:#0d1117!important;color:#ffffff!important;}',
                    '.cbi-page-actions{padding:12px!important;margin-top:12px!important;background:#0d1117!important;border-radius:14px!important;display:flex!important;flex-wrap:wrap!important;gap:8px!important;align-items:center!important;}',
                    '.cbi-page-actions .cbi-button-apply,.cbi-page-actions button.important{flex:1 1 100%!important;height:42px!important;min-height:42px!important;max-height:42px!important;}',
                    '.cbi-page-actions .cbi-button-save,.cbi-page-actions .cbi-button-reset{flex:1 1 calc(50% - 4px)!important;height:42px!important;min-height:42px!important;max-height:42px!important;}',
                    '.cbi-page-actions .cbi-dropdown{flex:1 1 100%!important;height:42px!important;min-height:42px!important;}',
                    '.cbi-dropdown{background:#151c26!important;background-color:#151c26!important;background-image:none!important;color:#ffffff!important;color-scheme:dark!important;border:none!important;border-radius:10px!important;box-shadow:none!important;}',
                    '.cbi-dropdown>ul,.cbi-dropdown>ul>li{background:#151c26!important;background-color:#151c26!important;background-image:none!important;color:#ffffff!important;border:none!important;box-shadow:none!important;}',
                    '.cbi-dropdown[open]>ul.dropdown{background:#0d1117!important;background-color:#0d1117!important;background-image:none!important;color:#ffffff!important;border:none!important;box-shadow:0 8px 24px rgba(0,0,0,0.85)!important;border-radius:10px!important;padding:4px!important;z-index:1100!important;}',
                    '.cbi-dropdown[open]>ul.dropdown>li{background:#151c26!important;background-color:#151c26!important;color:#ffffff!important;border-radius:8px!important;margin:2px 0!important;padding:8px 10px!important;}',
                    '.cbi-dropdown[open]>ul.dropdown>li:hover,.cbi-dropdown[open]>ul.dropdown>li.focus{background:#4ce5b6!important;background-color:#4ce5b6!important;color:#000000!important;}',
                    '.btn,button,input[type=button],input[type=submit],input[type=reset],.cbi-button,.cbi-button-add,.cbi-button-edit,.cbi-button-action,.cbi-button-neutral,.cbi-button-reload,.drag-handle{background:#151c26!important;background-color:#151c26!important;color:#ffffff!important;border:none!important;border-radius:10px!important;padding:9px 14px!important;font-weight:700!important;background-image:none!important;box-shadow:none!important;text-shadow:none!important;}',
                    '.cbi-button-add,.cbi-button-positive{background:rgba(76,229,182,0.18)!important;background-color:rgba(76,229,182,0.18)!important;color:#4ce5b6!important;}',
                    '.cbi-button-save{background:#1c2533!important;background-color:#1c2533!important;color:#4ce5b6!important;font-weight:800!important;}',
                    '.cbi-button-apply,button.important{background:#4ce5b6!important;background-color:#4ce5b6!important;color:#000000!important;font-weight:800!important;}',
                    '.cbi-button-apply:not([open])>ul,.cbi-button-apply:not([open])>ul>li,.cbi-button-apply>.open,.cbi-button-apply>.more,button.important>ul,button.important>ul>li,button.important>.open,button.important>.more{background:transparent!important;background-color:transparent!important;background-image:none!important;color:#000000!important;border:none!important;box-shadow:none!important;text-shadow:none!important;}',
                    '.cbi-button-apply *,button.important *{color:#000000!important;}',
                    '.cbi-button-reset,.cbi-button-negative,.cbi-button-remove{background:rgba(255,92,92,0.2)!important;background-color:rgba(255,92,92,0.2)!important;color:#ff6b6b!important;}',
                    'ul.dropdown-menu,.dropdown-menu,.open>.dropdown-menu,.alert-message,.alert,#modal_overlay,.modal,.modal-dialog,.modal-content{background:#151c26!important;background-color:#151c26!important;background-image:none!important;color:#ffffff!important;border:none!important;border-radius:12px!important;}'
                ].join('');
                var st = document.getElementById('__owrt_force_dark');
                if(!st){
                    st = document.createElement('style');
                    st.id = '__owrt_force_dark';
                    (document.head || document.documentElement).appendChild(st);
                }
                if(st.textContent !== css){ st.textContent = css; }
                var hdrs = document.querySelectorAll('header,.navbar,footer,.footer');
                for(var h = 0; h < hdrs.length; h++){
                    hdrs[h].style.setProperty('display', 'none', 'important');
                }
                var allUls = document.querySelectorAll('ul');
                for(var u = 0; u < allUls.length; u++){
                    var txt = allUls[u].textContent || '';
                    if(txt.indexOf('Статус') !== -1 && txt.indexOf('Система') !== -1 && txt.indexOf('Службы') !== -1){
                        allUls[u].style.setProperty('display', 'none', 'important');
                        if(allUls[u].parentElement && allUls[u].parentElement.tagName !== 'BODY'){
                            allUls[u].parentElement.style.setProperty('display', 'none', 'important');
                        }
                    }
                }
                var divs = document.querySelectorAll('div,p,span,a');
                for(var d = 0; d < divs.length; d++){
                    var t = (divs[d].textContent || '').trim();
                    if((t.indexOf('Powered by LuCI') !== -1 && divs[d].children.length <= 3) || (t === 'Выйти' && divs[d].children.length === 0)){
                        divs[d].style.setProperty('display', 'none', 'important');
                    }
                }
            })();
        """.trimIndent()
        view?.evaluateJavascript(js, null)
    }

    private fun updateOverlayNavHighlight(activeTab: String) {
        val activeColor = Color.parseColor("#4CE5B6")
        val inactiveColor = Color.parseColor("#CBD5E1")
        overlayNavItems.forEach { (key, pair) ->
            val color = if (key == activeTab) activeColor else inactiveColor
            pair.first.setImageDrawable(createTabIconDrawable(key, color))
            pair.second.setTextColor(color)
        }
    }

    private fun switchToTabFromOverlay(tabName: String) {
        closeLuciOverlay()
        mainWebView.evaluateJavascript("if(window.switchTab){window.switchTab('$tabName');}", null)
    }

    private fun setupLuciOverlay() {
        luciOverlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            visibility = View.GONE
        }

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#080B0F"))
            setPadding(dp(14), dp(10), dp(14), dp(10))
            gravity = Gravity.CENTER_VERTICAL
        }

        luciTitleView = TextView(this).apply {
            text = "Панель LuCI"
            setTextColor(Color.parseColor("#4CE5B6"))
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(10)
            }
        }

        val closeBg = GradientDrawable().apply {
            setColor(Color.parseColor("#2A1418"))
            cornerRadius = dp(10).toFloat()
        }

        val closeBtn = TextView(this).apply {
            text = "Закрыть"
            setTextColor(Color.parseColor("#FF5C5C"))
            background = closeBg
            textSize = 13f
            setTypeface(null, Typeface.BOLD)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setOnClickListener { closeLuciOverlay() }
        }

        topBar.addView(luciTitleView)
        topBar.addView(closeBtn)

        luciWebView = WebView(this)
        luciWebView.setBackgroundColor(Color.BLACK)
        configureWebView(luciWebView, forceDarkPage = true)
        luciWebView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = false

            @SuppressLint("WebViewClientOnReceivedSslError")
            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                handler?.proceed()
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                applyLuciDarkTheme(view)
            }

            override fun onPageCommitVisible(view: WebView?, url: String?) {
                super.onPageCommitVisible(view, url)
                applyLuciDarkTheme(view)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                applyLuciDarkTheme(view)
                view?.postDelayed({ applyLuciDarkTheme(view) }, 300)
                view?.postDelayed({ applyLuciDarkTheme(view) }, 900)

                val uEsc = JSONObject.quote(luciUser)
                val pEsc = JSONObject.quote(luciPass)
                val autoLoginJs = """
                    (function() {
                        var inputs = document.getElementsByTagName('input');
                        var u = null, p = null;
                        for (var i = 0; i < inputs.length; i++) {
                            if (inputs[i].name === 'luci_username') u = inputs[i];
                            if (inputs[i].name === 'luci_password') p = inputs[i];
                        }
                        if (u && p && !window.__luciSubmitted) {
                            window.__luciSubmitted = true;
                            u.value = $uEsc;
                            p.value = $pEsc;
                            var f = p.closest('form');
                            if (f) f.submit();
                        }
                    })();
                """.trimIndent()
                view?.evaluateJavascript(autoLoginJs, null)
            }
        }

        val bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#080B0F"))
            setPadding(dp(4), dp(8), dp(4), dp(12))
            weightSum = 5f
        }

        val tabs = listOf(
            "Обзор" to "overview",
            "Сервисы" to "services",
            "Клиенты" to "clients",
            "Тест" to "test",
            "Модем" to "modem"
        )

        overlayNavItems.clear()
        val defaultColor = Color.parseColor("#CBD5E1")
        tabs.forEach { (label, tabKey) ->
            val itemContainer = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(1), dp(4), dp(1), dp(4))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { switchToTabFromOverlay(tabKey) }
            }

            val iconView = ImageView(this).apply {
                setImageDrawable(createTabIconDrawable(tabKey, defaultColor))
                layoutParams = LinearLayout.LayoutParams(dp(21), dp(21)).apply {
                    bottomMargin = dp(4)
                }
            }

            val labelView = TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                textSize = 11f
                setTypeface(null, Typeface.BOLD)
                setTextColor(defaultColor)
                maxLines = 1
            }

            itemContainer.addView(iconView)
            itemContainer.addView(labelView)
            overlayNavItems[tabKey] = Pair(iconView, labelView)
            bottomBar.addView(itemContainer)
        }

        luciOverlay.addView(
            topBar,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        luciOverlay.addView(
            luciWebView,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        luciOverlay.addView(
            bottomBar,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        rootContainer.addView(
            luciOverlay,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
    }

    private fun closeLuciOverlay() {
        luciEntryUrl = ""
        luciOverlay.visibility = View.GONE
        luciWebView.stopLoading()
        luciWebView.clearHistory()
        luciWebView.loadUrl("about:blank")
    }

    private fun trustAllCertificates() {
        try {
            val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
                override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}
                override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
                override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
            })
            val sc = SSLContext.getInstance("TLS")
            sc.init(null, trustAllCerts, SecureRandom())
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.socketFactory)
            HttpsURLConnection.setDefaultHostnameVerifier { _, _ -> true }
        } catch (_: Exception) {
        }
    }

    private data class RawHttpResp(
        val code: Int,
        val body: String,
        val setCookies: List<String>,
        val tokenHeader: String
    )

    inner class RouterBridge {

        @JavascriptInterface
        fun exitApp() {
            scope.launch(Dispatchers.Main) {
                finish()
            }
        }

        @JavascriptInterface
        fun openLuci(fullUrl: String, title: String, user: String, pass: String, sourceTab: String) {
            scope.launch(Dispatchers.Main) {
                luciUser = user
                luciPass = pass
                luciEntryUrl = fullUrl
                luciTitleView.text = title
                updateOverlayNavHighlight(sourceTab)
                luciWebView.clearHistory()
                luciOverlay.visibility = View.VISIBLE
                luciWebView.loadUrl(fullUrl)
            }
        }

        @JavascriptInterface
        fun ubusCall(callbackId: String, routerUrl: String, payloadJson: String) {
            scope.launch(Dispatchers.IO) {
                val responseJson = JSONObject()
                try {
                    val cleanBase = routerUrl.trim().trimEnd('/')
                    val endpoint = "$cleanBase/ubus"
                    val url = URL(endpoint)
                    val conn = url.openConnection() as HttpURLConnection
                    conn.requestMethod = "POST"
                    conn.connectTimeout = 7000
                    conn.readTimeout = 10000
                    conn.doOutput = true
                    conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")

                    OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
                        writer.write(payloadJson)
                    }

                    val code = conn.responseCode
                    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                    val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""

                    responseJson.put("ok", code in 200..299)
                    responseJson.put("code", code)
                    responseJson.put("body", body)
                } catch (e: Exception) {
                    responseJson.put("ok", false)
                    responseJson.put("error", e.message ?: "Ошибка сети")
                }

                val js = "window.__onNativeCallback('$callbackId', ${JSONObject.quote(responseJson.toString())});"
                scope.launch(Dispatchers.Main) {
                    mainWebView.evaluateJavascript(js, null)
                }
            }
        }


        private fun sha256Bytes(input: ByteArray): ByteArray {
            return MessageDigest.getInstance("SHA-256").digest(input)
        }

        private fun sha256Hex(input: String): String {
            return sha256Bytes(input.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
        }

        private fun sha256Base64(input: String): String {
            // Huawei HiLink password_type=4 encodes Base64 of the 64-char ASCII hex SHA-256 string
            val hexStr = sha256Hex(input)
            return android.util.Base64.encodeToString(hexStr.toByteArray(Charsets.UTF_8), android.util.Base64.NO_WRAP)
        }

        private fun hmacSha256(key: ByteArray, data: ByteArray): ByteArray {
            val mac = javax.crypto.Mac.getInstance("HmacSHA256")
            mac.init(javax.crypto.spec.SecretKeySpec(key, "HmacSHA256"))
            return mac.doFinal(data)
        }

        private fun pbkdf2Sha256(password: String, salt: ByteArray, iterations: Int): ByteArray {
            val spec = javax.crypto.spec.PBEKeySpec(password.toCharArray(), salt, iterations, 256)
            val skf = javax.crypto.SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
            return skf.generateSecret(spec).encoded
        }

        private fun hexToBytes(hex: String): ByteArray {
            val clean = hex.trim()
            val len = clean.length
            val out = ByteArray(len / 2)
            var i = 0
            while (i + 1 < len) {
                out[i / 2] = clean.substring(i, i + 2).toInt(16).toByte()
                i += 2
            }
            return out
        }

        private fun bytesToHex(bytes: ByteArray): String {
            return bytes.joinToString("") { "%02x".format(it) }
        }

        private fun xorBytes(a: ByteArray, b: ByteArray): ByteArray {
            val len = minOf(a.size, b.size)
            val out = ByteArray(len)
            for (i in 0 until len) {
                out[i] = (a[i].toInt() xor b[i].toInt()).toByte()
            }
            return out
        }

        private fun extractXmlTag(xml: String, tag: String): String {
            val regex = Regex("<$tag>(.*?)</$tag>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
            return regex.find(xml)?.groupValues?.get(1)?.trim() ?: ""
        }

        private fun mergeCookies(existingCookie: String, setCookieHeaders: List<String>?): String {
            val jar = LinkedHashMap<String, String>()
            if (existingCookie.isNotEmpty()) {
                existingCookie.split(";").forEach { part ->
                    val kv = part.trim()
                    val eq = kv.indexOf('=')
                    if (eq > 0) jar[kv.substring(0, eq).trim()] = kv.substring(eq + 1).trim()
                }
            }
            setCookieHeaders?.forEach { raw ->
                val firstPart = raw.split(";")[0].trim()
                val eq = firstPart.indexOf('=')
                if (eq > 0) jar[firstPart.substring(0, eq).trim()] = firstPart.substring(eq + 1).trim()
            }
            return jar.entries.joinToString("; ") { "${it.key}=${it.value}" }
        }

        private fun httpRawRequest(
            fullUrl: String,
            method: String,
            body: String?,
            headers: Map<String, String>,
            connectTimeoutMs: Int = 5000,
            readTimeoutMs: Int = 7000
        ): RawHttpResp {
            val url = URL(fullUrl)
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = method
            conn.connectTimeout = connectTimeoutMs
            conn.readTimeout = readTimeoutMs
            conn.instanceFollowRedirects = true
            headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
            if (body != null && (method == "POST" || method == "PUT")) {
                conn.doOutput = true
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..399) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            val cookies = conn.headerFields["Set-Cookie"] ?: conn.headerFields["set-cookie"] ?: emptyList()
            val tokHdr = conn.getHeaderField("__RequestVerificationToken")
                ?: conn.getHeaderField("__RequestVerificationTokenone")
                ?: conn.getHeaderField("__RequestVerificationTokenTwo")
                ?: ""
            return RawHttpResp(code, text, cookies, tokHdr)
        }

        private val huaweiSessionStore = java.util.concurrent.ConcurrentHashMap<String, Pair<String, String>>()

        private fun refreshHuaweiSessionAndToken(
            baseUrl: String,
            cookieRef: MutableList<String>,
            tokenRef: MutableList<String>
        ): RawHttpResp {
            val baseHeaders = mutableMapOf(
                "Accept" to "*/*",
                "X-Requested-With" to "XMLHttpRequest"
            )
            if (cookieRef[0].isNotEmpty()) baseHeaders["Cookie"] = cookieRef[0]

            var tokResp = httpRawRequest(
                "$baseUrl/api/webserver/SesTokInfo",
                "GET",
                null,
                baseHeaders
            )
            cookieRef[0] = mergeCookies(cookieRef[0], tokResp.setCookies)
            if (tokResp.tokenHeader.isNotEmpty()) tokenRef[0] = tokResp.tokenHeader
            if (tokResp.code in 200..299 && tokResp.body.isNotEmpty()) {
                val t = extractXmlTag(tokResp.body, "TokInfo")
                val s = extractXmlTag(tokResp.body, "SesInfo")
                if (t.isNotEmpty()) tokenRef[0] = t
                if (s.isNotEmpty() && !cookieRef[0].contains("SessionID=", ignoreCase = true)) {
                    cookieRef[0] = mergeCookies(cookieRef[0], listOf(if (s.startsWith("SessionID=")) s else "SessionID=$s"))
                }
            } else {
                tokResp = httpRawRequest(
                    "$baseUrl/api/webserver/token",
                    "GET",
                    null,
                    mapOf("Accept" to "*/*", "X-Requested-With" to "XMLHttpRequest")
                )
                cookieRef[0] = mergeCookies(cookieRef[0], tokResp.setCookies)
                val t = extractXmlTag(tokResp.body, "token")
                if (t.isNotEmpty()) tokenRef[0] = t
            }
            if (tokenRef[0].isEmpty()) {
                val homeResp = httpRawRequest("$baseUrl/", "GET", null, mapOf("Accept" to "text/html,*/*"))
                cookieRef[0] = mergeCookies(cookieRef[0], homeResp.setCookies)
                val metaMatch = Regex("<meta[^>]+(?:name=[\"']csrf_token[\"'][^>]+content=[\"']([^\"']+)[\"']|content=[\"']([^\"']+)[\"'][^>]+name=[\"']csrf_token[\"'])", RegexOption.IGNORE_CASE).find(homeResp.body)
                if (metaMatch != null) {
                    tokenRef[0] = metaMatch.groupValues[1].ifEmpty { metaMatch.groupValues[2] }.trim()
                }
            }
            return tokResp
        }

        private fun scramRound(
            baseUrl: String,
            password: String,
            cookieRef: MutableList<String>,
            tokenRef: MutableList<String>,
            hmacKeyFirst: Boolean
        ): String {
            fun hdrs(): MutableMap<String, String> {
                val h = mutableMapOf(
                    "Accept" to "*/*",
                    "X-Requested-With" to "XMLHttpRequest",
                    "Content-Type" to "application/x-www-form-urlencoded; charset=UTF-8"
                )
                if (cookieRef[0].isNotEmpty()) h["Cookie"] = cookieRef[0]
                if (tokenRef[0].isNotEmpty()) h["__RequestVerificationToken"] = tokenRef[0]
                return h
            }

            val nonceBytes = ByteArray(32)
            SecureRandom().nextBytes(nonceBytes)
            val firstNonce = bytesToHex(nonceBytes)

            val challengeXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><request><username>admin</username><firstnonce>$firstNonce</firstnonce><mode>1</mode></request>"
            val chResp = httpRawRequest("$baseUrl/api/user/challenge_login", "POST", challengeXml, hdrs())
            cookieRef[0] = mergeCookies(cookieRef[0], chResp.setCookies)
            val chBodyTok = extractXmlTag(chResp.body, "TokInfo").ifEmpty { extractXmlTag(chResp.body, "token") }
            if (chResp.tokenHeader.isNotEmpty()) tokenRef[0] = chResp.tokenHeader else if (chBodyTok.isNotEmpty()) tokenRef[0] = chBodyTok

            val chErr = extractXmlTag(chResp.body, "code")
            if (chResp.code !in 200..299 || chErr.isNotEmpty()) {
                return "CHALLENGE_UNSUPPORTED:${chErr.ifEmpty { chResp.code.toString() }}"
            }

            val saltHex = extractXmlTag(chResp.body, "salt")
            val serverNonce = extractXmlTag(chResp.body, "servernonce")
            val iterStr = extractXmlTag(chResp.body, "iterations")
            val iterations = iterStr.toIntOrNull() ?: 100

            if (saltHex.isEmpty() || serverNonce.isEmpty()) {
                return "CHALLENGE_EMPTY"
            }

            val saltBytes = try {
                val cleanSalt = saltHex.trim()
                if (cleanSalt.length % 2 == 0 && cleanSalt.matches(Regex("[0-9a-fA-F]+"))) {
                    hexToBytes(cleanSalt)
                } else {
                    android.util.Base64.decode(cleanSalt, android.util.Base64.DEFAULT)
                }
            } catch (_: Exception) {
                saltHex.toByteArray(Charsets.UTF_8)
            }

            val saltedPassword = pbkdf2Sha256(password, saltBytes, iterations)
            val clientKey = if (hmacKeyFirst) {
                hmacSha256(saltedPassword, "Client Key".toByteArray(Charsets.UTF_8))
            } else {
                hmacSha256("Client Key".toByteArray(Charsets.UTF_8), saltedPassword)
            }
            val storedKey = sha256Bytes(clientKey)
            val authMsg = "$firstNonce,$serverNonce,$serverNonce"
            val clientSignature = hmacSha256(storedKey, authMsg.toByteArray(Charsets.UTF_8))
            val clientProof = bytesToHex(xorBytes(clientKey, clientSignature))

            val authXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><request><clientproof>$clientProof</clientproof><finalnonce>$serverNonce</finalnonce></request>"
            val authResp = httpRawRequest("$baseUrl/api/user/authentication_login", "POST", authXml, hdrs())
            cookieRef[0] = mergeCookies(cookieRef[0], authResp.setCookies)
            if (authResp.tokenHeader.isNotEmpty()) tokenRef[0] = authResp.tokenHeader

            val authErr = extractXmlTag(authResp.body, "code")
            return if (authErr.isNotEmpty() && authErr != "0") {
                "AUTH_ERR:$authErr"
            } else {
                "OK"
            }
        }

        private fun performHuaweiScramLogin(
            baseUrl: String,
            password: String,
            cookieRef: MutableList<String>,
            tokenRef: MutableList<String>
        ): String {
            val firstTry = scramRound(baseUrl, password, cookieRef, tokenRef, hmacKeyFirst = true)
            if (firstTry == "OK" || firstTry != "AUTH_ERR:108006") {
                return firstTry
            }
            refreshHuaweiSessionAndToken(baseUrl, cookieRef, tokenRef)
            return scramRound(baseUrl, password, cookieRef, tokenRef, hmacKeyFirst = false)
        }

        private fun rsaPkcs1EncryptHex(modulusHex: String, exponentHex: String, plainBytes: ByteArray): String? {
            return try {
                val n = java.math.BigInteger(modulusHex.trim(), 16)
                val e = java.math.BigInteger(exponentHex.trim(), 16)
                val keyLen = (n.bitLength() + 7) / 8
                if (keyLen < plainBytes.size + 11) return null
                val psLen = keyLen - plainBytes.size - 3
                val ps = ByteArray(psLen)
                val rng = SecureRandom()
                var i = 0
                while (i < ps.size) {
                    val b = rng.nextInt(255) + 1
                    ps[i] = b.toByte()
                    i += 1
                }
                val em = ByteArray(keyLen)
                em[0] = 0x00.toByte()
                em[1] = 0x02.toByte()
                System.arraycopy(ps, 0, em, 2, ps.size)
                em[2 + ps.size] = 0x00.toByte()
                System.arraycopy(plainBytes, 0, em, 3 + ps.size, plainBytes.size)
                val m = java.math.BigInteger(1, em)
                val c = m.modPow(e, n)
                val cBytes = c.toByteArray()
                val out = ByteArray(keyLen)
                val srcOffset = if (cBytes.size > keyLen) cBytes.size - keyLen else 0
                val dstOffset = if (cBytes.size < keyLen) keyLen - cBytes.size else 0
                val copyLen = minOf(keyLen, cBytes.size - srcOffset)
                System.arraycopy(cBytes, srcOffset, out, dstOffset, copyLen)
                bytesToHex(out)
            } catch (_: Exception) {
                null
            }
        }

        private fun sendStandardLoginAttempt(
            baseUrl: String,
            authDigest: String,
            cookieRef: MutableList<String>,
            tokenRef: MutableList<String>
        ): String {
            val h = mutableMapOf(
                "Accept" to "*/*",
                "X-Requested-With" to "XMLHttpRequest",
                "Content-Type" to "application/x-www-form-urlencoded; charset=UTF-8"
            )
            if (cookieRef[0].isNotEmpty()) h["Cookie"] = cookieRef[0]
            if (tokenRef[0].isNotEmpty()) h["__RequestVerificationToken"] = tokenRef[0]

            val loginXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><request><Username>admin</Username><Password>$authDigest</Password><password_type>4</password_type></request>"
            val loginResp = httpRawRequest("$baseUrl/api/user/login", "POST", loginXml, h)
            cookieRef[0] = mergeCookies(cookieRef[0], loginResp.setCookies)
            if (loginResp.tokenHeader.isNotEmpty()) {
                tokenRef[0] = loginResp.tokenHeader
            } else {
                val bodyTok = extractXmlTag(loginResp.body, "TokInfo").ifEmpty { extractXmlTag(loginResp.body, "token") }
                if (bodyTok.isNotEmpty()) tokenRef[0] = bodyTok
            }

            val loginErr = extractXmlTag(loginResp.body, "code")
            return if (loginErr.isNotEmpty() && loginErr != "0") {
                "AUTH_ERR:$loginErr"
            } else {
                "OK"
            }
        }

        private fun performHuaweiStandardLogin(
            baseUrl: String,
            password: String,
            cookieRef: MutableList<String>,
            tokenRef: MutableList<String>
        ): String {
            val passHashB64 = sha256Base64(password)
            val h = mutableMapOf(
                "Accept" to "*/*",
                "X-Requested-With" to "XMLHttpRequest"
            )
            if (cookieRef[0].isNotEmpty()) h["Cookie"] = cookieRef[0]
            val pubResp = httpRawRequest("$baseUrl/api/webserver/publickey", "GET", null, h)
            cookieRef[0] = mergeCookies(cookieRef[0], pubResp.setCookies)
            if (pubResp.tokenHeader.isNotEmpty()) tokenRef[0] = pubResp.tokenHeader
            val pubN = extractXmlTag(pubResp.body, "encpubkeyn")
            val pubE = extractXmlTag(pubResp.body, "encpubkeye")
            if (pubN.isNotEmpty() && pubE.isNotEmpty()) {
                val payload = (passHashB64 + tokenRef[0]).toByteArray(Charsets.UTF_8)
                val encHex = rsaPkcs1EncryptHex(pubN, pubE, payload)
                if (encHex != null) {
                    val rsaRes = sendStandardLoginAttempt(baseUrl, encHex, cookieRef, tokenRef)
                    if (rsaRes == "OK" || (rsaRes != "AUTH_ERR:108006" && rsaRes != "AUTH_ERR:125003")) {
                        return rsaRes
                    }
                    refreshHuaweiSessionAndToken(baseUrl, cookieRef, tokenRef)
                }
            }

            val stdDigest = if (tokenRef[0].isNotEmpty()) {
                sha256Base64("admin" + passHashB64 + tokenRef[0])
            } else {
                sha256Hex(password)
            }
            return sendStandardLoginAttempt(baseUrl, stdDigest, cookieRef, tokenRef)
        }

        @JavascriptInterface
        fun huaweiDiscover(callbackId: String) {
            scope.launch(Dispatchers.IO) {
                val candidates = listOf("192.168.8.1", "192.168.1.1", "192.168.3.1", "192.168.0.1", "192.168.100.1")
                val out = JSONObject()
                var foundIp = ""
                var foundModel = ""
                val errRegex = Regex("<error>\\s*<code>\\d+</code>", RegexOption.IGNORE_CASE)
                for (ip in candidates) {
                    try {
                        val resp = httpRawRequest(
                            "http://$ip/api/webserver/SesTokInfo",
                            "GET",
                            null,
                            mapOf("Accept" to "application/xml,*/*"),
                            connectTimeoutMs = 1200,
                            readTimeoutMs = 1200
                        )
                        val b = resp.body
                        if (b.contains("<SesInfo>") || b.contains("<TokInfo>") || b.contains("<token>") || errRegex.containsMatchIn(b)) {
                            foundIp = ip
                            try {
                                val infoResp = httpRawRequest(
                                    "http://$ip/api/device/basic_information",
                                    "GET",
                                    null,
                                    mapOf("Accept" to "application/xml,*/*"),
                                    connectTimeoutMs = 1200,
                                    readTimeoutMs = 1200
                                )
                                foundModel = extractXmlTag(infoResp.body, "devicename")
                            } catch (_: Exception) {}
                            break
                        }
                    } catch (_: Exception) {}
                }
                if (foundIp.isNotEmpty()) {
                    out.put("ok", true)
                    out.put("ip", foundIp)
                    out.put("model", foundModel)
                } else {
                    out.put("ok", false)
                    out.put("error", "Роутер Huawei в локальной сети не обнаружен")
                }
                val js = "window.__onNativeCallback('$callbackId', ${JSONObject.quote(out.toString())});"
                scope.launch(Dispatchers.Main) {
                    mainWebView.evaluateJavascript(js, null)
                }
            }
        }

        @JavascriptInterface
        fun huaweiPollSignal(callbackId: String, hostOrUrl: String, password: String) {
            scope.launch(Dispatchers.IO) {
                val out = JSONObject()
                try {
                    val trimmed = hostOrUrl.trim().trimEnd('/')
                    val baseUrl = if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) trimmed else "http://$trimmed"

                    val savedPair = huaweiSessionStore[baseUrl]
                    val cookieRef = mutableListOf(savedPair?.first ?: "")
                    val tokenRef = mutableListOf(savedPair?.second ?: "")

                    fun buildHeaders(): MutableMap<String, String> {
                        val h = mutableMapOf(
                            "Accept" to "*/*",
                            "X-Requested-With" to "XMLHttpRequest"
                        )
                        if (cookieRef[0].isNotEmpty()) h["Cookie"] = cookieRef[0]
                        if (tokenRef[0].isNotEmpty()) h["__RequestVerificationToken"] = tokenRef[0]
                        return h
                    }

                    fun buildNoTokenHeaders(): MutableMap<String, String> {
                        val h = mutableMapOf(
                            "Accept" to "*/*",
                            "X-Requested-With" to "XMLHttpRequest"
                        )
                        if (cookieRef[0].isNotEmpty()) h["Cookie"] = cookieRef[0]
                        return h
                    }

                    var sigResp = RawHttpResp(0, "", emptyList(), "")
                    var needFreshLogin = true

                    if (savedPair != null && cookieRef[0].isNotEmpty()) {
                        sigResp = httpRawRequest("$baseUrl/api/device/signal", "GET", null, buildHeaders())
                        cookieRef[0] = mergeCookies(cookieRef[0], sigResp.setCookies)
                        if (sigResp.tokenHeader.isNotEmpty()) tokenRef[0] = sigResp.tokenHeader
                        if (extractXmlTag(sigResp.body, "code") == "100003") {
                            refreshHuaweiSessionAndToken(baseUrl, cookieRef, tokenRef)
                            sigResp = httpRawRequest("$baseUrl/api/device/signal", "GET", null, buildHeaders())
                            cookieRef[0] = mergeCookies(cookieRef[0], sigResp.setCookies)
                            if (sigResp.tokenHeader.isNotEmpty()) tokenRef[0] = sigResp.tokenHeader
                        }
                        if (sigResp.code in 200..299 && extractXmlTag(sigResp.body, "code").isEmpty() && sigResp.body.isNotEmpty()) {
                            needFreshLogin = false
                        }
                    }

                    if (needFreshLogin) {
                        cookieRef[0] = ""
                        tokenRef[0] = ""
                        huaweiSessionStore.remove(baseUrl)

                        val stateResp = httpRawRequest("$baseUrl/api/user/state-login", "GET", null, buildNoTokenHeaders())
                        if (stateResp.code !in 200..299 && stateResp.body.isEmpty()) {
                            out.put("ok", false)
                            out.put("error", "Huawei не отвечает по адресу $baseUrl (HTTP ${stateResp.code})")
                        } else {
                            cookieRef[0] = mergeCookies(cookieRef[0], stateResp.setCookies)
                            val loginState = extractXmlTag(stateResp.body, "State").trim()
                            val pwType = extractXmlTag(stateResp.body, "password_type").trim()

                            refreshHuaweiSessionAndToken(baseUrl, cookieRef, tokenRef)

                            if (loginState == "0") {
                                sigResp = httpRawRequest("$baseUrl/api/device/signal", "GET", null, buildHeaders())
                                cookieRef[0] = mergeCookies(cookieRef[0], sigResp.setCookies)
                                if (sigResp.tokenHeader.isNotEmpty()) tokenRef[0] = sigResp.tokenHeader
                            } else if (password.isEmpty()) {
                                out.put("ok", false)
                                out.put("error", "Введите пароль роутера Huawei")
                            } else {
                                var authResult = if (pwType == "3") {
                                    performHuaweiScramLogin(baseUrl, password, cookieRef, tokenRef)
                                } else {
                                    performHuaweiStandardLogin(baseUrl, password, cookieRef, tokenRef)
                                }

                                if (authResult == "AUTH_ERR:108003") {
                                    refreshHuaweiSessionAndToken(baseUrl, cookieRef, tokenRef)
                                    val checkSig = httpRawRequest("$baseUrl/api/device/signal", "GET", null, buildHeaders())
                                    if (checkSig.code in 200..299 && checkSig.body.contains("<rsrp>", true)) {
                                        sigResp = checkSig
                                        authResult = "OK"
                                    }
                                }

                                if (authResult == "OK") {
                                    if (tokenRef[0].isEmpty()) {
                                        refreshHuaweiSessionAndToken(baseUrl, cookieRef, tokenRef)
                                    }
                                    sigResp = httpRawRequest("$baseUrl/api/device/signal", "GET", null, buildHeaders())
                                    cookieRef[0] = mergeCookies(cookieRef[0], sigResp.setCookies)
                                    if (sigResp.tokenHeader.isNotEmpty()) tokenRef[0] = sigResp.tokenHeader
                                    if (extractXmlTag(sigResp.body, "code") == "100003") {
                                        refreshHuaweiSessionAndToken(baseUrl, cookieRef, tokenRef)
                                        sigResp = httpRawRequest("$baseUrl/api/device/signal", "GET", null, buildHeaders())
                                        cookieRef[0] = mergeCookies(cookieRef[0], sigResp.setCookies)
                                        if (sigResp.tokenHeader.isNotEmpty()) tokenRef[0] = sigResp.tokenHeader
                                    }
                                } else {
                                    val c = authResult.substringAfter(":")
                                    val hint = when (c) {
                                        "108006" -> "Неверный логин или пароль роутера Huawei (код 108006)"
                                        "108003" -> "Сессия Huawei занята — закройте веб-страницу роутера или подождите пару секунд (код 108003)"
                                        "108007", "108010" -> "Слишком много попыток входа Huawei, подождите 1–2 минуты (код $c)"
                                        else -> "Ошибка авторизации Huawei ($authResult)"
                                    }
                                    out.put("ok", false)
                                    out.put("error", hint)
                                }
                            }
                        }
                    }

                    if (true) {

                        if (!out.has("ok")) {

                            val monResp = httpRawRequest("$baseUrl/api/monitoring/status", "GET", null, buildHeaders())
                            val plmnResp = httpRawRequest("$baseUrl/api/net/current-plmn", "GET", null, buildHeaders())
                            val infoResp = httpRawRequest("$baseUrl/api/device/basic_information", "GET", null, buildHeaders())
                            val trafResp = httpRawRequest("$baseUrl/api/monitoring/traffic-statistics", "GET", null, buildHeaders())

                            val signalJson = JSONObject()
                            val signalTags = listOf(
                                "pci", "cell_id", "rsrp", "rsrq", "rssi", "sinr",
                                "band", "earfcn", "dlbandwidth", "ulbandwidth",
                                "mode", "cqi0", "cqi1", "txpower", "transmode", "mimo", "rrc_status",
                                "dl_mcs", "ul_mcs", "nrrsrp", "nrsinr", "nrrsrq", "nrband", "nrearfcn", "nrpci"
                            )
                            signalTags.forEach { tag ->
                                val v = extractXmlTag(sigResp.body, tag)
                                if (v.isNotEmpty()) signalJson.put(tag, v)
                            }

                            val monJson = JSONObject()
                            listOf("ServiceStatus", "ConnectionStatus", "SimStatus", "SignalIcon", "CurrentNetworkType", "CurrentNetworkTypeEx", "WanIPAddress", "PrimaryDns", "SecondaryDns").forEach { tag ->
                                val v = extractXmlTag(monResp.body, tag)
                                if (v.isNotEmpty()) monJson.put(tag, v)
                            }

                            val plmnJson = JSONObject()
                            listOf("FullName", "ShortName", "Numeric", "Rat").forEach { tag ->
                                val v = extractXmlTag(plmnResp.body, tag)
                                if (v.isNotEmpty()) plmnJson.put(tag, v)
                            }

                            val modelName = extractXmlTag(infoResp.body, "devicename")
                            if (modelName.isNotEmpty()) out.put("model", modelName)

                            val trafJson = JSONObject()
                            listOf("CurrentDownloadRate", "CurrentUploadRate", "TotalDownload", "TotalUpload").forEach { tag ->
                                val v = extractXmlTag(trafResp.body, tag)
                                if (v.isNotEmpty()) trafJson.put(tag, v)
                            }

                            val ok = sigResp.code in 200..299 && signalJson.length() > 0 && extractXmlTag(sigResp.body, "code").isEmpty()
                            if (ok) {
                                huaweiSessionStore[baseUrl] = Pair(cookieRef[0], tokenRef[0])
                            } else {
                                huaweiSessionStore.remove(baseUrl)
                            }
                            out.put("ok", ok)
                            out.put("signal", signalJson)
                            out.put("monitoring", monJson)
                            out.put("plmn", plmnJson)
                            out.put("traffic", trafJson)
                            if (!ok) {
                                val apiCode = extractXmlTag(sigResp.body, "code")
                                out.put(
                                    "error",
                                    if (apiCode.isNotEmpty())
                                        "Huawei отклонил запрос сигнала (код $apiCode)"
                                    else
                                        "Нет данных сигнала от Huawei (HTTP ${sigResp.code})"
                                )
                            }
                        }
                    }
                } catch (e: Exception) {
                    out.put("ok", false)
                    out.put("error", "Ошибка сети при опросе Huawei: ${e.message ?: e.javaClass.simpleName}")
                }

                val js = "window.__onNativeCallback('$callbackId', ${JSONObject.quote(out.toString())});"
                scope.launch(Dispatchers.Main) {
                    mainWebView.evaluateJavascript(js, null)
                }
            }
        }

        @JavascriptInterface
        fun sshExec(callbackId: String, routerUrl: String, sshPort: Int, user: String, pass: String, command: String) {
            scope.launch {
                val host = extractHost(routerUrl)
                val res = sshManager.execCommand(host, sshPort, user, pass, command)
                val json = JSONObject()
                if (res.isSuccess) {
                    json.put("ok", true)
                    json.put("output", res.getOrDefault(""))
                } else {
                    json.put("ok", false)
                    json.put("error", res.exceptionOrNull()?.message ?: "Ошибка SSH")
                }
                val js = "window.__onNativeCallback('$callbackId', ${JSONObject.quote(json.toString())});"
                mainWebView.evaluateJavascript(js, null)
            }
        }

        private fun extractHost(rawUrl: String): String {
            return try {
                val normalized = if (rawUrl.startsWith("http://") || rawUrl.startsWith("https://")) rawUrl else "http://$rawUrl"
                URI(normalized).host ?: rawUrl.replace("http://", "").replace("https://", "").split(":")[0].split("/")[0]
            } catch (_: Exception) {
                rawUrl.replace("http://", "").replace("https://", "").split(":")[0].split("/")[0]
            }
        }
    }
}
