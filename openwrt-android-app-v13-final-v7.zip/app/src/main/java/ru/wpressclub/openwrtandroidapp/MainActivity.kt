package ru.wpressclub.openwrtandroidapp

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.GradientDrawable
import android.net.http.SslError
import android.os.Bundle
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.JavascriptInterface
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.webkit.WebSettingsCompat
import androidx.webkit.WebViewFeature
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.CookieHandler
import java.net.CookieManager as NetCookieManager
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.security.MessageDigest
import java.security.SecureRandom
import java.security.cert.X509Certificate
import javax.net.ssl.HttpsURLConnection
import javax.net.ssl.SSLContext
import javax.net.ssl.TrustManager
import javax.net.ssl.X509TrustManager

class MainActivity : AppCompatActivity() {

    private lateinit var rootContainer: FrameLayout
    private lateinit var mainWebView: WebView
    private lateinit var luciOverlay: LinearLayout
    private lateinit var luciTitleView: TextView
    private lateinit var luciWebView: WebView
    private val overlayNavItems = mutableMapOf<String, Pair<ImageView, TextView>>()

    private val sshManager = SshManager()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private var luciUser: String = "root"
    private var luciPass: String = ""
    private var luciEntryUrl: String = ""

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES)
        super.onCreate(savedInstanceState)
        trustAllCertificates()

        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        window.statusBarColor = Color.BLACK
        window.navigationBarColor = Color.parseColor("#080B0F")

        rootContainer = FrameLayout(this)
        rootContainer.setBackgroundColor(Color.BLACK)
        setContentView(rootContainer)

        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)

        mainWebView = WebView(this)
        mainWebView.setBackgroundColor(Color.BLACK)
        configureWebView(mainWebView, forceDarkPage = false)
        mainWebView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = false

            @SuppressLint("WebViewClientOnReceivedSslError")
            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                handler?.proceed()
            }
        }
        mainWebView.addJavascriptInterface(RouterBridge(), "AndroidBridge")
        rootContainer.addView(
            mainWebView,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )

        setupLuciOverlay()

        mainWebView.loadUrl("file:///android_asset/index.html")

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (luciOverlay.visibility == View.VISIBLE) {
                    handleLuciOverlayBack()
                } else {
                    mainWebView.evaluateJavascript("if(window.handleAppBack){window.handleAppBack();}", null)
                }
            }
        })
    }

    private fun handleLuciOverlayBack() {
        val currentUrl = (luciWebView.url ?: "").trimEnd('/')
        val entryClean = luciEntryUrl.trimEnd('/')
        if (currentUrl.isEmpty() || currentUrl == "about:blank" || currentUrl == entryClean) {
            closeLuciOverlay()
            return
        }
        val list = luciWebView.copyBackForwardList()
        if (list.currentIndex > 0) {
            val prevUrl = list.getItemAtIndex(list.currentIndex - 1)?.url ?: ""
            if (prevUrl.isEmpty() || prevUrl == "about:blank") {
                closeLuciOverlay()
                return
            }
            luciWebView.goBack()
        } else {
            closeLuciOverlay()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Suppress("DEPRECATION")
    private fun configureWebView(wv: WebView, forceDarkPage: Boolean) {
        CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true)
        val s = wv.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        s.useWideViewPort = true
        s.loadWithOverviewMode = true
        s.builtInZoomControls = true
        s.displayZoomControls = false

        if (forceDarkPage) {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.ALGORITHMIC_DARKENING)) {
                WebSettingsCompat.setAlgorithmicDarkeningAllowed(s, true)
            }
            if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK)) {
                WebSettingsCompat.setForceDark(s, WebSettings.FORCE_DARK_ON)
            }
            if (WebViewFeature.isFeatureSupported(WebViewFeature.FORCE_DARK_STRATEGY)) {
                WebSettingsCompat.setForceDarkStrategy(
                    s,
                    WebSettingsCompat.DARK_STRATEGY_PREFER_WEB_THEME_OVER_USER_AGENT_DARKENING
                )
            }
        }
        wv.webChromeClient = WebChromeClient()
    }

    private fun dp(value: Int): Int {
        return TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()
    }

    private fun createTabIconDrawable(tabKey: String, colorInt: Int): BitmapDrawable {
        val sizePx = dp(21)
        val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)
        val scale = sizePx / 24f
        canvas.scale(scale, scale)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = colorInt
            style = Paint.Style.STROKE
            strokeWidth = 2f
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
        }

        when (tabKey) {
            "overview" -> {
                canvas.drawRoundRect(RectF(3f, 3f, 10f, 10f), 1.5f, 1.5f, paint)
                canvas.drawRoundRect(RectF(14f, 3f, 21f, 10f), 1.5f, 1.5f, paint)
                canvas.drawRoundRect(RectF(3f, 14f, 10f, 21f), 1.5f, 1.5f, paint)
                canvas.drawRoundRect(RectF(14f, 14f, 21f, 21f), 1.5f, 1.5f, paint)
            }
            "services" -> {
                val p1 = Path().apply {
                    moveTo(12f, 2f); lineTo(2f, 7f); lineTo(12f, 12f); lineTo(22f, 7f); close()
                }
                val p2 = Path().apply {
                    moveTo(2f, 12f); lineTo(12f, 17f); lineTo(22f, 12f)
                }
                val p3 = Path().apply {
                    moveTo(2f, 17f); lineTo(12f, 22f); lineTo(22f, 17f)
                }
                canvas.drawPath(p1, paint)
                canvas.drawPath(p2, paint)
                canvas.drawPath(p3, paint)
            }
            "clients" -> {
                val p1 = Path().apply {
                    moveTo(17f, 21f); lineTo(17f, 19f)
                    arcTo(RectF(9f, 15f, 17f, 23f), 0f, -90f, false)
                    lineTo(5f, 15f)
                    arcTo(RectF(1f, 15f, 9f, 23f), -90f, -90f, false)
                    lineTo(1f, 21f)
                }
                canvas.drawPath(p1, paint)
                canvas.drawCircle(9f, 7f, 4f, paint)
                val p2 = Path().apply {
                    moveTo(23f, 21f); lineTo(23f, 19f)
                    arcTo(RectF(15f, 15f, 23f, 23f), 0f, -65f, false)
                }
                val p3 = Path().apply {
                    arcTo(RectF(12f, 3f, 20f, 11f), -65f, 130f, false)
                }
                canvas.drawPath(p2, paint)
                canvas.drawPath(p3, paint)
            }
            "modem" -> {
                canvas.drawLine(4f, 20f, 4f, 15f, paint)
                canvas.drawLine(9f, 20f, 9f, 11f, paint)
                canvas.drawLine(14f, 20f, 14f, 7f, paint)
                canvas.drawLine(19f, 20f, 19f, 4f, paint)
            }
            "terminal" -> {
                val p1 = Path().apply {
                    moveTo(4f, 17f); lineTo(10f, 11f); lineTo(4f, 5f)
                }
                canvas.drawPath(p1, paint)
                canvas.drawLine(12f, 19f, 20f, 19f, paint)
            }
            "more" -> {
                canvas.drawCircle(12f, 5f, 1.5f, paint)
                canvas.drawCircle(12f, 12f, 1.5f, paint)
                canvas.drawCircle(12f, 19f, 1.5f, paint)
            }
        }
        return BitmapDrawable(resources, bmp)
    }

    private fun applyLuciDarkTheme(view: WebView?) {
        val js = """
            (function(){
                if(document.documentElement&&document.documentElement.hasAttribute('data-darkmode')){
                    document.documentElement.removeAttribute('data-darkmode');
                }
                var css = [
                    ':root{--background-color-delta-l-sign:1;--background-color-h:215;--background-color-s:28%;--background-color-l:8%;--text-color-delta-l-sign:-1;--text-color-h:0;--text-color-s:0%;--text-color-l:100%;--border-color-delta-l-sign:1;--primary-color-high:#4ce5b6;--primary-color-medium:#38b890;--primary-color-low:#268f6f;--on-primary-color:#000000;color-scheme:dark!important;}',
                    'html,body{background:#000000!important;background-color:#000000!important;background-image:none!important;color:#ffffff!important;color-scheme:dark!important;margin:0!important;padding:0!important;}',
                    'header,.navbar,#modemenu,.nav,.cbi-navigation,.cbi-navigation-step,footer,.footer{display:none!important;height:0!important;overflow:hidden!important;}',
                    '#maincontent,.main,.main-right,.container,#view{background:#000000!important;background-color:#000000!important;background-image:none!important;padding:14px 12px 28px!important;margin:0!important;max-width:100%!important;}',
                    '.cbi-map,.cbi-section,.cbi-section-node,.cbi-value,fieldset,.panel,.card,.alert-message,[data-tab]{background:#0d1117!important;background-color:#0d1117!important;background-image:none!important;color:#ffffff!important;border:none!important;box-shadow:none!important;border-radius:14px!important;}',
                    'table,tbody,thead,tfoot,tr,td,th,.table,.tr,.td,.th,.table-wrapper,.cbi-section-table,.cbi-section-table-row,.cbi-section-table-cell,.cbi-rowstyle-1,.cbi-rowstyle-2,.cbi-value-field,.table .tr,.table .td,.table .th,.cbi-section-table .tr,.cbi-section-table .td,.cbi-section-table .th{background:#0d1117!important;background-color:#0d1117!important;background-image:none!important;color:#ffffff!important;border:none!important;box-shadow:none!important;}',
                    '.ifacebox,.ifacebox-head,.ifacebox-body,.ifacebadge,span.ifacebadge,div.ifacebadge,.td .ifacebadge,.tr .ifacebadge,.table .td .ifacebadge,.cbi-value-field .ifacebadge,.port,.network-status-table,.wifi-status-table,[data-widget],.cbi-value-field>div,.cbi-section-table-cell>div{background:#151c26!important;background-color:#151c26!important;background-image:none!important;color:#ffffff!important;border:none!important;box-shadow:none!important;border-radius:12px!important;}',
                    '.ifacebox-head{background:#1c2533!important;background-color:#1c2533!important;background-image:none!important;padding:6px 8px!important;margin-bottom:6px!important;}',
                    '.ifacebox-head.active{background:#4ce5b6!important;background-color:#4ce5b6!important;color:#000000!important;}',
                    '.ifacebox-head.active *{color:#000000!important;}',
                    'h1,h2,h3,h4,legend{color:#4ce5b6!important;font-weight:800!important;border:none!important;}',
                    'label,.cbi-value-title,.cbi-value-description,.cbi-section-descr,p,span,div,td,th,.td,.th,li,strong,small{color:#ffffff!important;border-color:transparent!important;}',
                    'a{color:#4ce5b6!important;text-decoration:none!important;}',
                    '.tabs,.cbi-tabmenu,ul.tabs,ul.cbi-tabmenu{background:#0d1117!important;background-color:#0d1117!important;background-image:none!important;border:none!important;border-radius:14px!important;padding:6px!important;display:flex!important;flex-wrap:wrap!important;gap:6px!important;margin:0 0 12px 0!important;}',
                    '.tabs>li,.cbi-tabmenu>li,.cbi-tab,.cbi-tab-disabled{background:#151c26!important;background-color:#151c26!important;background-image:none!important;border:none!important;border-radius:10px!important;margin:0!important;padding:0!important;}',
                    '.tabs>li>a,.cbi-tabmenu>li>a,.cbi-tab>a,.cbi-tab-disabled>a{background:transparent!important;color:#ffffff!important;border:none!important;padding:8px 12px!important;display:block!important;font-weight:700!important;}',
                    '.tabs>li.active,.cbi-tabmenu>li.cbi-tab,li.cbi-tab{background:#4ce5b6!important;background-color:#4ce5b6!important;}',
                    '.tabs>li.active>a,.cbi-tabmenu>li.cbi-tab>a,li.cbi-tab>a{color:#000000!important;font-weight:800!important;}',
                    '.cbi-dynlist,.cbi-dynlist>.item,.cbi-dynlist>.add-item,.cbi-dynlist>.add-item>input,.cbi-dynlist>.add-item>span,.cbi-dynlist>.add-item>div{background:#151c26!important;background-color:#151c26!important;background-image:none!important;color:#ffffff!important;border:none!important;box-shadow:none!important;}',
                    'input,select,textarea,.cbi-input-text,.cbi-input-select{background:#151c26!important;background-color:#151c26!important;background-image:none!important;color:#ffffff!important;color-scheme:dark!important;border:none!important;border-radius:10px!important;padding:10px 12px!important;min-height:44px!important;height:auto!important;}',
                    'select option{background:#0d1117!important;background-color:#0d1117!important;color:#ffffff!important;}',
                    '.cbi-page-actions{padding:12px!important;margin-top:12px!important;background:#0d1117!important;border-radius:14px!important;display:flex!important;flex-wrap:wrap!important;gap:8px!important;align-items:center!important;}',
                    '.cbi-page-actions .cbi-button-apply,.cbi-page-actions button.important{flex:1 1 100%!important;height:42px!important;min-height:42px!important;max-height:42px!important;}',
                    '.cbi-page-actions .cbi-button-save,.cbi-page-actions .cbi-button-reset{flex:1 1 calc(50% - 4px)!important;height:42px!important;min-height:42px!important;max-height:42px!important;}',
                    '.cbi-page-actions .cbi-dropdown{flex:1 1 100%!important;height:42px!important;min-height:42px!important;}',
                    '.cbi-dropdown{background:#151c26!important;background-color:#151c26!important;background-image:none!important;color:#ffffff!important;color-scheme:dark!important;border:none!important;border-radius:10px!important;box-shadow:none!important;}',
                    '.cbi-dropdown>ul,.cbi-dropdown>ul>li{background:#151c26!important;background-color:#151c26!important;background-image:none!important;color:#ffffff!important;border:none!important;box-shadow:none!important;}',
                    '.cbi-dropdown[open]>ul.dropdown{background:#0d1117!important;background-color:#0d1117!important;background-image:none!important;color:#ffffff!important;border:none!important;box-shadow:0 8px 24px rgba(0,0,0,0.85)!important;border-radius:10px!important;padding:4px!important;z-index:1100!important;}',
                    '.cbi-dropdown[open]>ul.dropdown>li{background:#151c26!important;background-color:#151c26!important;color:#ffffff!important;border-radius:8px!important;margin:2px 0!important;padding:8px 10px!important;}',
                    '.cbi-dropdown[open]>ul.dropdown>li:hover,.cbi-dropdown[open]>ul.dropdown>li.focus{background:#4ce5b6!important;background-color:#4ce5b6!important;color:#000000!important;}',
                    '.btn,button,input[type=button],input[type=submit],input[type=reset],.cbi-button,.cbi-button-add,.cbi-button-edit,.cbi-button-action,.cbi-button-neutral,.cbi-button-reload,.drag-handle{background:#151c26!important;background-color:#151c26!important;color:#ffffff!important;border:none!important;border-radius:10px!important;padding:9px 14px!important;font-weight:700!important;background-image:none!important;box-shadow:none!important;text-shadow:none!important;}',
                    '.cbi-button-add,.cbi-button-positive{background:rgba(76,229,182,0.18)!important;background-color:rgba(76,229,182,0.18)!important;color:#4ce5b6!important;}',
                    '.cbi-button-save{background:#1c2533!important;background-color:#1c2533!important;color:#4ce5b6!important;font-weight:800!important;}',
                    '.cbi-button-apply,button.important{background:#4ce5b6!important;background-color:#4ce5b6!important;color:#000000!important;font-weight:800!important;}',
                    '.cbi-button-apply:not([open])>ul,.cbi-button-apply:not([open])>ul>li,.cbi-button-apply>.open,.cbi-button-apply>.more,button.important>ul,button.important>ul>li,button.important>.open,button.important>.more{background:transparent!important;background-color:transparent!important;background-image:none!important;color:#000000!important;border:none!important;box-shadow:none!important;text-shadow:none!important;}',
                    '.cbi-button-apply *,button.important *{color:#000000!important;}',
                    '.cbi-button-reset,.cbi-button-negative,.cbi-button-remove{background:rgba(255,92,92,0.2)!important;background-color:rgba(255,92,92,0.2)!important;color:#ff6b6b!important;}',
                    'ul.dropdown-menu,.dropdown-menu,.open>.dropdown-menu,.alert-message,.alert,#modal_overlay,.modal,.modal-dialog,.modal-content{background:#151c26!important;background-color:#151c26!important;background-image:none!important;color:#ffffff!important;border:none!important;border-radius:12px!important;}'
                ].join('');
                var st = document.getElementById('__owrt_force_dark');
                if(!st){
                    st = document.createElement('style');
                    st.id = '__owrt_force_dark';
                    (document.head || document.documentElement).appendChild(st);
                }
                if(st.textContent !== css){ st.textContent = css; }
                var hdrs = document.querySelectorAll('header,.navbar,footer,.footer');
                for(var h = 0; h < hdrs.length; h++){
                    hdrs[h].style.setProperty('display', 'none', 'important');
                }
                var allUls = document.querySelectorAll('ul');
                for(var u = 0; u < allUls.length; u++){
                    var txt = allUls[u].textContent || '';
                    if(txt.indexOf('Статус') !== -1 && txt.indexOf('Система') !== -1 && txt.indexOf('Службы') !== -1){
                        allUls[u].style.setProperty('display', 'none', 'important');
                        if(allUls[u].parentElement && allUls[u].parentElement.tagName !== 'BODY'){
                            allUls[u].parentElement.style.setProperty('display', 'none', 'important');
                        }
                    }
                }
                var divs = document.querySelectorAll('div,p,span,a');
                for(var d = 0; d < divs.length; d++){
                    var t = (divs[d].textContent || '').trim();
                    if((t.indexOf('Powered by LuCI') !== -1 && divs[d].children.length <= 3) || (t === 'Выйти' && divs[d].children.length === 0)){
                        divs[d].style.setProperty('display', 'none', 'important');
                    }
                }
            })();
        """.trimIndent()
        view?.evaluateJavascript(js, null)
    }

    private fun updateOverlayNavHighlight(activeTab: String) {
        val activeColor = Color.parseColor("#4CE5B6")
        val inactiveColor = Color.parseColor("#CBD5E1")
        overlayNavItems.forEach { (key, pair) ->
            val color = if (key == activeTab) activeColor else inactiveColor
            pair.first.setImageDrawable(createTabIconDrawable(key, color))
            pair.second.setTextColor(color)
        }
    }

    private fun switchToTabFromOverlay(tabName: String) {
        closeLuciOverlay()
        mainWebView.evaluateJavascript("if(window.switchTab){window.switchTab('$tabName');}", null)
    }

    private fun setupLuciOverlay() {
        luciOverlay = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            visibility = View.GONE
        }

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#080B0F"))
            setPadding(dp(14), dp(10), dp(14), dp(10))
            gravity = Gravity.CENTER_VERTICAL
        }

        luciTitleView = TextView(this).apply {
            text = "Панель LuCI"
            setTextColor(Color.parseColor("#4CE5B6"))
            textSize = 16f
            setTypeface(null, Typeface.BOLD)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = dp(10)
            }
        }

        val closeBg = GradientDrawable().apply {
            setColor(Color.parseColor("#2A1418"))
            cornerRadius = dp(10).toFloat()
        }

        val closeBtn = TextView(this).apply {
            text = "Закрыть"
            setTextColor(Color.parseColor("#FF5C5C"))
            background = closeBg
            textSize = 13f
            setTypeface(null, Typeface.BOLD)
            setPadding(dp(14), dp(8), dp(14), dp(8))
            setOnClickListener { closeLuciOverlay() }
        }

        topBar.addView(luciTitleView)
        topBar.addView(closeBtn)

        luciWebView = WebView(this)
        luciWebView.setBackgroundColor(Color.BLACK)
        configureWebView(luciWebView, forceDarkPage = true)
        luciWebView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean = false

            @SuppressLint("WebViewClientOnReceivedSslError")
            override fun onReceivedSslError(view: WebView?, handler: SslErrorHandler?, error: SslError?) {
                handler?.proceed()
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                applyLuciDarkTheme(view)
            }

            override fun onPageCommitVisible(view: WebView?, url: String?) {
                super.onPageCommitVisible(view, url)
                applyLuciDarkTheme(view)
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                applyLuciDarkTheme(view)
                view?.postDelayed({ applyLuciDarkTheme(view) }, 300)
                view?.postDelayed({ applyLuciDarkTheme(view) }, 900)

                val uEsc = JSONObject.quote(luciUser)
                val pEsc = JSONObject.quote(luciPass)
                val autoLoginJs = """
                    (function() {
                        var inputs = document.getElementsByTagName('input');
                        var u = null, p = null;
                        for (var i = 0; i < inputs.length; i++) {
                            if (inputs[i].name === 'luci_username') u = inputs[i];
                            if (inputs[i].name === 'luci_password') p = inputs[i];
                        }
                        if (u && p && !window.__luciSubmitted) {
                            window.__luciSubmitted = true;
                            u.value = $uEsc;
                            p.value = $pEsc;
                            var f = p.closest('form');
                            if (f) f.submit();
                        }
                    })();
                """.trimIndent()
                view?.evaluateJavascript(autoLoginJs, null)
            }
        }

        val bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(Color.parseColor("#080B0F"))
            setPadding(dp(4), dp(8), dp(4), dp(12))
            weightSum = 5f
        }

        val tabs = listOf(
            "Обзор" to "overview",
            "Сервисы" to "services",
            "Клиенты" to "clients",
            "Терминал" to "terminal",
            "Модем" to "modem"
        )

        overlayNavItems.clear()
        val defaultColor = Color.parseColor("#CBD5E1")
        tabs.forEach { (label, tabKey) ->
            val itemContainer = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(1), dp(4), dp(1), dp(4))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
                setOnClickListener { switchToTabFromOverlay(tabKey) }
            }

            val iconView = ImageView(this).apply {
                setImageDrawable(createTabIconDrawable(tabKey, defaultColor))
                layoutParams = LinearLayout.LayoutParams(dp(21), dp(21)).apply {
                    bottomMargin = dp(4)
                }
            }

            val labelView = TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                textSize = 11f
                setTypeface(null, Typeface.BOLD)
                setTextColor(defaultColor)
                maxLines = 1
            }

            itemContainer.addView(iconView)
            itemContainer.addView(labelView)
            overlayNavItems[tabKey] = Pair(iconView, labelView)
            bottomBar.addView(itemContainer)
        }

        luciOverlay.addView(
            topBar,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )
        luciOverlay.addView(
            luciWebView,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        luciOverlay.addView(
            bottomBar,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        )

        rootContainer.addView(
            luciOverlay,
            FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
        )
    }

    private fun closeLuciOverlay() {
        luciEntryUrl = ""
        luciOverlay.visibility = View.GONE
        luciWebView.stopLoading()
        luciWebView.clearHistory()
        luciWebView.loadUrl("about:blank")
    }

    private fun trustAllCertificates() {
        try {
            val trustAllCerts = arrayOf<TrustManager>(object : X509TrustManager {
                override fun checkClientTrusted(chain: Array<X509Certificate>, authType: String) {}
                override fun checkServerTrusted(chain: Array<X509Certificate>, authType: String) {}
                override fun getAcceptedIssuers(): Array<X509Certificate> = arrayOf()
            })
            val sc = SSLContext.getInstance("TLS")
            sc.init(null, trustAllCerts, SecureRandom())
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.socketFactory)
            HttpsURLConnection.setDefaultHostnameVerifier { _, _ -> true }
        } catch (_: Exception) {
        }
    }

    inner class RouterBridge {

        @JavascriptInterface
        fun exitApp() {
            scope.launch(Dispatchers.Main) {
                finish()
            }
        }

        @JavascriptInterface
        fun openLuci(fullUrl: String, title: String, user: String, pass: String, sourceTab: String) {
            scope.launch(Dispatchers.Main) {
                luciUser = user
                luciPass = pass
                luciEntryUrl = fullUrl
                luciTitleView.text = title
                updateOverlayNavHighlight(sourceTab)
                luciWebView.clearHistory()
                luciOverlay.visibility = View.VISIBLE
                luciWebView.loadUrl(fullUrl)
            }
        }

        @JavascriptInterface
        fun ubusCall(callbackId: String, routerUrl: String, payloadJson: String) {
            scope.launch(Dispatchers.IO) {
                val responseJson = JSONObject()
                try {
                    val cleanBase = routerUrl.trim().trimEnd('/')
                    val endpoint = "$cleanBase/ubus"
                    val url = URL(endpoint)
                    val conn = url.openConnection() as HttpURLConnection
                    conn.requestMethod = "POST"
                    conn.connectTimeout = 7000
                    conn.readTimeout = 10000
                    conn.doOutput = true
                    conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")

                    OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { writer ->
                        writer.write(payloadJson)
                    }

                    val code = conn.responseCode
                    val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                    val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""

                    responseJson.put("ok", code in 200..299)
                    responseJson.put("code", code)
                    responseJson.put("body", body)
                } catch (e: Exception) {
                    responseJson.put("ok", false)
                    responseJson.put("error", e.message ?: "Ошибка сети")
                }

                val js = "window.__onNativeCallback('$callbackId', ${JSONObject.quote(responseJson.toString())});"
                scope.launch(Dispatchers.Main) {
                    mainWebView.evaluateJavascript(js, null)
                }
            }
        }


        private val modemCookies = NetCookieManager().also {
            CookieHandler.setDefault(it)
        }

        private fun sha256Hex(input: String): String {
            val md = MessageDigest.getInstance("SHA-256")
            val bytes = md.digest(input.toByteArray(Charsets.UTF_8))
            return bytes.joinToString("") { "%02x".format(it) }
        }

        private fun sha256Base64(input: String): String {
            val md = MessageDigest.getInstance("SHA-256")
            val bytes = md.digest(input.toByteArray(Charsets.UTF_8))
            return android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP)
        }

        private fun extractXmlTag(xml: String, tag: String): String {
            val regex = Regex("<$tag>(.*?)</$tag>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
            return regex.find(xml)?.groupValues?.get(1)?.trim() ?: ""
        }

        private fun httpRawRequest(
            fullUrl: String,
            method: String,
            body: String?,
            headers: Map<String, String>
        ): Pair<Int, String> {
            val url = URL(fullUrl)
            val conn = url.openConnection() as HttpURLConnection
            conn.requestMethod = method
            conn.connectTimeout = 6500
            conn.readTimeout = 8000
            conn.instanceFollowRedirects = false
            headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
            if (body != null && (method == "POST" || method == "PUT")) {
                conn.doOutput = true
                OutputStreamWriter(conn.outputStream, Charsets.UTF_8).use { it.write(body) }
            }
            val code = conn.responseCode
            val stream = if (code in 200..399) conn.inputStream else conn.errorStream
            val text = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            return Pair(code, text)
        }

        @JavascriptInterface
        fun huaweiPollSignal(callbackId: String, hostOrUrl: String, password: String) {
            scope.launch(Dispatchers.IO) {
                val out = JSONObject()
                try {
                    val trimmed = hostOrUrl.trim().trimEnd('/')
                    val baseUrl = if (trimmed.startsWith("http://") || trimmed.startsWith("https://")) trimmed else "http://$trimmed"

                    // 1. Fetch SesTokInfo
                    val (tokCode, tokBody) = httpRawRequest(
                        "$baseUrl/api/webserver/SesTokInfo",
                        "GET",
                        null,
                        mapOf("Accept" to "*/*", "X-Requested-With" to "XMLHttpRequest")
                    )
                    if (tokCode !in 200..299 || tokBody.isEmpty()) {
                        out.put("ok", false)
                        out.put("error", "Нет ответа от Huawei (HTTP $tokCode)")
                    } else {
                        var tokInfo = extractXmlTag(tokBody, "TokInfo")
                        var sesInfo = extractXmlTag(tokBody, "SesInfo")

                        val baseHeaders = mutableMapOf(
                            "Accept" to "*/*",
                            "X-Requested-With" to "XMLHttpRequest"
                        )
                        if (sesInfo.isNotEmpty()) {
                            baseHeaders["Cookie"] = if (sesInfo.startsWith("SessionID=")) sesInfo else "SessionID=$sesInfo"
                        }
                        if (tokInfo.isNotEmpty()) {
                            baseHeaders["__RequestVerificationToken"] = tokInfo
                        }

                        // 2. Try reading signal right away; if login/auth required and password provided, login via Huawei B636 scheme
                        var (sigCode, sigXml) = httpRawRequest("$baseUrl/api/device/signal", "GET", null, baseHeaders)
                        val needsAuth = sigXml.contains("125002") || sigXml.contains("125003") || sigXml.contains("<error>") && extractXmlTag(sigXml, "code").isNotEmpty()

                        if (needsAuth && password.isNotEmpty()) {
                            // Huawei HiLink (B636 / newer Balong): base64(sha256_hex(username + base64(sha256_hex(password)) + token)) or sha256_hex
                            val passHashHex = sha256Hex(password)
                            val passHashB64 = sha256Base64(passHashHex)
                            val authDigest = if (tokInfo.isNotEmpty()) {
                                sha256Base64("admin" + passHashB64 + tokInfo)
                            } else {
                                passHashHex
                            }
                            val loginXml = "<?xml version=\"1.0\" encoding=\"UTF-8\"?><request><Username>admin</Username><Password>$authDigest</Password><password_type>4</password_type></request>"
                            val loginHeaders = baseHeaders.toMutableMap().apply {
                                put("Content-Type", "application/x-www-form-urlencoded; charset=UTF-8")
                            }
                            val (_, loginResp) = httpRawRequest("$baseUrl/api/user/login", "POST", loginXml, loginHeaders)
                            val errCode = extractXmlTag(loginResp, "code")
                            if (errCode.isNotEmpty() && errCode != "0") {
                                out.put("ok", false)
                                out.put("error", "Ошибка авторизации Huawei (код $errCode)")
                            } else {
                                // Refresh SesTokInfo after login
                                val (_, tok2Body) = httpRawRequest("$baseUrl/api/webserver/SesTokInfo", "GET", null, baseHeaders)
                                val tok2 = extractXmlTag(tok2Body, "TokInfo")
                                val ses2 = extractXmlTag(tok2Body, "SesInfo")
                                if (ses2.isNotEmpty()) {
                                    baseHeaders["Cookie"] = if (ses2.startsWith("SessionID=")) ses2 else "SessionID=$ses2"
                                }
                                if (tok2.isNotEmpty()) {
                                    baseHeaders["__RequestVerificationToken"] = tok2
                                }
                                val retry = httpRawRequest("$baseUrl/api/device/signal", "GET", null, baseHeaders)
                                sigCode = retry.first
                                sigXml = retry.second
                            }
                        }

                        if (!out.has("ok")) {
                            val (_, monXml) = httpRawRequest("$baseUrl/api/monitoring/status", "GET", null, baseHeaders)
                            val (_, plmnXml) = httpRawRequest("$baseUrl/api/net/current-plmn", "GET", null, baseHeaders)

                            val signalJson = JSONObject()
                            val signalTags = listOf(
                                "pci", "cell_id", "rsrp", "rsrq", "rssi", "sinr",
                                "band", "earfcn", "dlbandwidth", "ulbandwidth",
                                "mode", "cqi", "txpower"
                            )
                            signalTags.forEach { tag ->
                                val v = extractXmlTag(sigXml, tag)
                                if (v.isNotEmpty()) signalJson.put(tag, v)
                            }

                            val monJson = JSONObject()
                            listOf("SignalIcon", "CurrentNetworkType", "CurrentNetworkTypeEx", "WanIPAddress", "PrimaryDns", "SecondaryDns").forEach { tag ->
                                val v = extractXmlTag(monXml, tag)
                                if (v.isNotEmpty()) monJson.put(tag, v)
                            }

                            val plmnJson = JSONObject()
                            listOf("FullName", "ShortName", "Numeric", "Rat").forEach { tag ->
                                val v = extractXmlTag(plmnXml, tag)
                                if (v.isNotEmpty()) plmnJson.put(tag, v)
                            }

                            out.put("ok", sigCode in 200..299 && signalJson.length() > 0)
                            out.put("signal", signalJson)
                            out.put("monitoring", monJson)
                            out.put("plmn", plmnJson)
                            if (!(sigCode in 200..299 && signalJson.length() > 0)) {
                                out.put("error", "Не удалось прочитать телеметрию сигнала (проверьте пароль или доступ к API)")
                            }
                        }
                    }
                } catch (e: Exception) {
                    out.put("ok", false)
                    out.put("error", e.message ?: "Ошибка подключения к модему")
                }

                val js = "window.__onNativeCallback('$callbackId', ${JSONObject.quote(out.toString())});"
                scope.launch(Dispatchers.Main) {
                    mainWebView.evaluateJavascript(js, null)
                }
            }
        }

        @JavascriptInterface
        fun sshExec(callbackId: String, routerUrl: String, sshPort: Int, user: String, pass: String, command: String) {
            scope.launch {
                val host = extractHost(routerUrl)
                val res = sshManager.execCommand(host, sshPort, user, pass, command)
                val json = JSONObject()
                if (res.isSuccess) {
                    json.put("ok", true)
                    json.put("output", res.getOrDefault(""))
                } else {
                    json.put("ok", false)
                    json.put("error", res.exceptionOrNull()?.message ?: "Ошибка SSH")
                }
                val js = "window.__onNativeCallback('$callbackId', ${JSONObject.quote(json.toString())});"
                mainWebView.evaluateJavascript(js, null)
            }
        }

        private fun extractHost(rawUrl: String): String {
            return try {
                val normalized = if (rawUrl.startsWith("http://") || rawUrl.startsWith("https://")) rawUrl else "http://$rawUrl"
                URI(normalized).host ?: rawUrl.replace("http://", "").replace("https://", "").split(":")[0].split("/")[0]
            } catch (_: Exception) {
                rawUrl.replace("http://", "").replace("https://", "").split(":")[0].split("/")[0]
            }
        }
    }
}
