(function() {
  if (window.__TestSpeedActivityReady) return;
  window.__TestSpeedActivityReady = true;
  var running = false;
  var animTimer = null;
  var currentVal = 0;
  var targetVal = 0;
  var accentColor = '#4ce5b6';
  var SERVERS = {
    yandex: {
      name: 'Яндекс CDN (Россия · Москва)',
      pingHost: '77.88.8.8',
      dlUrls: [
        'http://mirror.yandex.ru/ubuntu-releases/24.04.2/ubuntu-24.04.2-live-server-amd64.iso',
        'http://mirror.yandex.ru/debian/ls-lR.gz'
      ],
      ulUrls: [
        'https://speed.cloudflare.com/__up',
        'http://spb.speedtest.rt.ru:8080/speedtest/upload.php',
        'http://msk.speedtest.rt.ru:8080/speedtest/upload.php',
        'http://spb.speedtest.megafon.ru:8080/speedtest/upload.php',
        'http://spb.speedtest.tele2.ru:8080/speedtest/upload.php'
      ]
    },
    selectel: {
      name: 'Selectel (Россия · Санкт-Петербург)',
      pingHost: '188.93.16.19',
      dlUrls: [
        'http://speedtest.selectel.ru/100MB',
        'http://speedtest.selectel.ru/10MB'
      ],
      ulUrls: [
        'https://speed.cloudflare.com/__up',
        'http://spb.speedtest.rt.ru:8080/speedtest/upload.php',
        'http://speedtest.sknt.ru:8080/speedtest/upload.php',
        'http://spb.speedtest.megafon.ru:8080/speedtest/upload.php'
      ]
    },
    megafon: {
      name: 'МегаФон (Россия)',
      pingHost: '193.232.248.45',
      dlUrls: [
        'http://spb.speedtest.megafon.ru:8080/speedtest/random4000x4000.jpg',
        'http://msk.speedtest.megafon.ru:8080/speedtest/random4000x4000.jpg',
        'http://speedtest.selectel.ru/100MB'
      ],
      ulUrls: [
        'http://spb.speedtest.megafon.ru:8080/speedtest/upload.php',
        'http://msk.speedtest.megafon.ru:8080/speedtest/upload.php',
        'https://speed.cloudflare.com/__up',
        'http://spb.speedtest.rt.ru:8080/speedtest/upload.php'
      ]
    },
    tele2: {
      name: 'Tele2 / T2 (Россия)',
      pingHost: '193.124.212.1',
      dlUrls: [
        'http://spb.speedtest.tele2.ru:8080/speedtest/random4000x4000.jpg',
        'http://msk.speedtest.tele2.ru:8080/speedtest/random4000x4000.jpg',
        'http://speedtest.selectel.ru/100MB'
      ],
      ulUrls: [
        'http://spb.speedtest.tele2.ru:8080/speedtest/upload.php',
        'http://msk.speedtest.tele2.ru:8080/speedtest/upload.php',
        'https://speed.cloudflare.com/__up',
        'http://spb.speedtest.rt.ru:8080/speedtest/upload.php'
      ]
    },
    beeline: {
      name: 'Билайн (Россия)',
      pingHost: '212.119.240.1',
      dlUrls: [
        'http://spb.speedtest.beeline.ru:8080/speedtest/random4000x4000.jpg',
        'http://msk.speedtest.beeline.ru:8080/speedtest/random4000x4000.jpg',
        'http://speedtest.selectel.ru/100MB'
      ],
      ulUrls: [
        'http://spb.speedtest.beeline.ru:8080/speedtest/upload.php',
        'http://msk.speedtest.beeline.ru:8080/speedtest/upload.php',
        'https://speed.cloudflare.com/__up',
        'http://spb.speedtest.rt.ru:8080/speedtest/upload.php'
      ]
    },
    mts: {
      name: 'МТС (Россия)',
      pingHost: '213.87.0.1',
      dlUrls: [
        'http://spb.speedtest.mts.ru:8080/speedtest/random4000x4000.jpg',
        'http://msk.speedtest.mts.ru:8080/speedtest/random4000x4000.jpg',
        'http://speedtest.selectel.ru/100MB'
      ],
      ulUrls: [
        'http://spb.speedtest.mts.ru:8080/speedtest/upload.php',
        'http://msk.speedtest.mts.ru:8080/speedtest/upload.php',
        'https://speed.cloudflare.com/__up',
        'http://spb.speedtest.rt.ru:8080/speedtest/upload.php'
      ]
    },
    rostelecom: {
      name: 'Ростелеком (Россия)',
      pingHost: '212.188.0.1',
      dlUrls: [
        'http://spb.speedtest.rt.ru:8080/speedtest/random4000x4000.jpg',
        'http://msk.speedtest.rt.ru:8080/speedtest/random4000x4000.jpg',
        'http://speedtest.selectel.ru/100MB'
      ],
      ulUrls: [
        'http://spb.speedtest.rt.ru:8080/speedtest/upload.php',
        'http://msk.speedtest.rt.ru:8080/speedtest/upload.php',
        'https://speed.cloudflare.com/__up',
        'http://speedtest.sknt.ru:8080/speedtest/upload.php'
      ]
    },
    domru: {
      name: 'Дом.ru (Россия)',
      pingHost: '89.189.160.1',
      dlUrls: [
        'http://speedtest.spb.domru.ru:8080/speedtest/random4000x4000.jpg',
        'http://speedtest.msk.domru.ru:8080/speedtest/random4000x4000.jpg',
        'http://speedtest.selectel.ru/100MB'
      ],
      ulUrls: [
        'http://speedtest.spb.domru.ru:8080/speedtest/upload.php',
        'http://speedtest.msk.domru.ru:8080/speedtest/upload.php',
        'https://speed.cloudflare.com/__up',
        'http://spb.speedtest.rt.ru:8080/speedtest/upload.php'
      ]
    },
    skynet: {
      name: 'SkyNet (Россия · Санкт-Петербург)',
      pingHost: '80.64.80.1',
      dlUrls: [
        'http://speedtest.sknt.ru:8080/speedtest/random4000x4000.jpg',
        'http://speedtest.selectel.ru/100MB'
      ],
      ulUrls: [
        'http://speedtest.sknt.ru:8080/speedtest/upload.php',
        'https://speed.cloudflare.com/__up',
        'http://spb.speedtest.rt.ru:8080/speedtest/upload.php'
      ]
    }
  };
  var HISTORY_KEY = 'openwrt_speedtest_history_v1';
  var MAX_HISTORY = 30;
  function loadHistory() {
    try {
      var raw = localStorage.getItem(HISTORY_KEY);
      var parsed = raw ? JSON.parse(raw) : [];
      return Array.isArray(parsed) ? parsed : [];
    } catch (_) {
      return [];
    }
  }
  function saveHistory(list) {
    try {
      localStorage.setItem(HISTORY_KEY, JSON.stringify(list.slice(0, MAX_HISTORY)));
    } catch (_) {}
  }
  function formatDateTime(ts) {
    try {
      var d = new Date(ts || Date.now());
      var pad = function(n) { return n < 10 ? '0' + n : String(n); };
      return pad(d.getDate()) + '.' + pad(d.getMonth() + 1) + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
    } catch (_) {
      return '';
    }
  }
  function escHtml(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }
  function renderHistoryList() {
    var box = document.getElementById('sp-history-list');
    var cnt = document.getElementById('sp-history-count');
    if (!box) return;
    var items = loadHistory();
    if (cnt) cnt.textContent = String(items.length);
    if (!items.length) {
      box.innerHTML = '<div style="font-size:13px;color:#94a3b8;text-align:center;padding:12px 6px;">Сохранённых результатов пока нет</div>';
      return;
    }
    var html = '';
    for (var i = 0; i < items.length; i++) {
      var it = items[i];
      var dl = it.dl || {};
      var ul = it.ul || {};
      var dlMax = dl.hasData ? dl.max.toFixed(2) : 'Н/Д';
      var dlMin = dl.hasData ? dl.min.toFixed(2) : 'Н/Д';
      var dlAvg = dl.hasData ? dl.avg.toFixed(2) : 'Н/Д';
      var ulMax = ul.hasData ? ul.max.toFixed(2) : 'Н/Д';
      var ulMin = ul.hasData ? ul.min.toFixed(2) : 'Н/Д';
      var ulAvg = ul.hasData ? ul.avg.toFixed(2) : 'Н/Д';
      var pingStr = (it.ping != null && it.ping !== '') ? (escHtml(it.ping) + ' мс') : '—';
      var jitStr = (it.jitter != null && it.jitter !== '') ? (escHtml(it.jitter) + ' мс') : '—';
      html +=
        '<div style="background:#070a0e;border-radius:12px;padding:11px 12px;margin-bottom:8px;">' +
          '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:8px;font-size:12px;">' +
            '<span style="color:#ffffff;font-weight:800;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;">' + escHtml(it.server || 'Сервер') + '</span>' +
            '<span style="color:#94a3b8;flex-shrink:0;">' + escHtml(formatDateTime(it.ts)) + '</span>' +
          '</div>' +
          '<div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:12px;">' +
            '<div style="background:#0d1117;border-radius:10px;padding:8px 10px;">' +
              '<div style="color:#4ce5b6;font-weight:800;margin-bottom:4px;">↓ ВХОДЯЩАЯ</div>' +
              '<div style="display:flex;justify-content:space-between;color:#cbd5e1;"><span>Макс</span><strong style="color:#fff;">' + escHtml(dlMax) + '</strong></div>' +
              '<div style="display:flex;justify-content:space-between;color:#cbd5e1;"><span>Мин</span><strong style="color:#fff;">' + escHtml(dlMin) + '</strong></div>' +
              '<div style="display:flex;justify-content:space-between;color:#cbd5e1;"><span>Среднее</span><strong style="color:#4ce5b6;">' + escHtml(dlAvg) + '</strong></div>' +
            '</div>' +
            '<div style="background:#0d1117;border-radius:10px;padding:8px 10px;">' +
              '<div style="color:#ffb84d;font-weight:800;margin-bottom:4px;">↑ ИСХОДЯЩАЯ</div>' +
              '<div style="display:flex;justify-content:space-between;color:#cbd5e1;"><span>Макс</span><strong style="color:#fff;">' + escHtml(ulMax) + '</strong></div>' +
              '<div style="display:flex;justify-content:space-between;color:#cbd5e1;"><span>Мин</span><strong style="color:#fff;">' + escHtml(ulMin) + '</strong></div>' +
              '<div style="display:flex;justify-content:space-between;color:#cbd5e1;"><span>Среднее</span><strong style="color:#ffb84d;">' + escHtml(ulAvg) + '</strong></div>' +
            '</div>' +
          '</div>' +
          '<div style="margin-top:6px;font-size:11.5px;color:#94a3b8;display:flex;justify-content:space-between;">' +
            '<span>Ping: ' + pingStr + ' · Jitter: ' + jitStr + '</span>' +
            '<span>Мбит/с</span>' +
          '</div>' +
        '</div>';
    }
    box.innerHTML = html;
  }
  function recordResult(entry) {
    if (!entry) return;
    var hasDl = entry.dl && entry.dl.hasData;
    var hasUl = entry.ul && entry.ul.hasData;
    if (!hasDl && !hasUl) return;
    var list = loadHistory();
    list.unshift(entry);
    saveHistory(list);
    renderHistoryList();
  }
  function clearHistory() {
    saveHistory([]);
    renderHistoryList();
  }
  function toggleHistoryPanel() {
    var panel = document.getElementById('sp-history-panel');
    if (!panel) return;
    var isHidden = panel.classList.contains('hidden');
    panel.classList.toggle('hidden', !isHidden);
    if (isHidden) renderHistoryList();
  }
  function calcStats(samples, totalAvg) {
    var valid = (samples || []).filter(function(v) { return typeof v === 'number' && !isNaN(v) && v > 0.05; });
    if (valid.length === 0) {
      if (typeof totalAvg === 'number' && totalAvg > 0.05) {
        return { hasData: true, max: totalAvg, min: totalAvg, avg: totalAvg };
      }
      return { hasData: false, max: 0, min: 0, avg: 0 };
    }
    var maxV = Math.max.apply(null, valid);
    var minV = Math.min.apply(null, valid);
    var avgV = (typeof totalAvg === 'number' && totalAvg > 0.05)
      ? totalAvg
      : (valid.reduce(function(a, b) { return a + b; }, 0) / valid.length);
    return { hasData: true, max: maxV, min: minV, avg: avgV };
  }
  function initDom() {
    var host = document.getElementById('tab-test');
    if (!host) return;
    if (!document.getElementById('sp-start-circle')) {
      host.innerHTML =
        '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px;">' +
          '<div class="metric-box" style="margin:0;padding:12px 14px;">' +
            '<div class="metric-label"><span style="color:#4ce5b6;font-weight:900;">↓</span> СКАЧАТЬ</div>' +
            '<div style="display:flex;align-items:baseline;gap:6px;">' +
              '<div class="metric-value" id="sp-dl-val" style="font-size:22px;">—</div>' +
              '<span style="font-size:12px;color:#94a3b8;font-weight:700;">Мбит/с</span>' +
            '</div>' +
          '</div>' +
          '<div class="metric-box" style="margin:0;padding:12px 14px;">' +
            '<div class="metric-label"><span style="color:#ffb84d;font-weight:900;">↑</span> ЗАГРУЗИТЬ</div>' +
            '<div style="display:flex;align-items:baseline;gap:6px;">' +
              '<div class="metric-value" id="sp-ul-val" style="font-size:22px;">—</div>' +
              '<span style="font-size:12px;color:#94a3b8;font-weight:700;" id="sp-ul-unit">Мбит/с</span>' +
            '</div>' +
          '</div>' +
        '</div>' +
        '<div style="display:flex;justify-content:space-around;align-items:center;background:var(--surface);border-radius:14px;padding:10px 12px;margin-bottom:14px;font-size:13px;">' +
          '<div><span style="color:#94a3b8;font-weight:700;">Ping</span> <span id="sp-ping-val" style="color:#fff;font-weight:800;">—</span> <span style="color:#94a3b8;font-size:12px;">мс</span></div>' +
          '<div style="width:1px;height:16px;background:rgba(255,255,255,0.1);"></div>' +
          '<div><span style="color:#94a3b8;font-weight:700;">Jitter</span> <span id="sp-jitter-val" style="color:#fff;font-weight:800;">—</span> <span style="color:#94a3b8;font-size:12px;">мс</span></div>' +
          '<div style="width:1px;height:16px;background:rgba(255,255,255,0.1);"></div>' +
          '<span class="badge badge-up" id="sp-status" style="margin:0;">Готов</span>' +
        '</div>' +
        '<div style="display:flex;flex-direction:column;align-items:center;justify-content:center;padding:4px 0 12px;min-height:282px;">' +
          '<div id="sp-circle-wrap" style="display:flex;align-items:center;justify-content:center;height:270px;">' +
            '<button type="button" id="sp-start-circle" onclick="window.TestSpeedActivity.start()" style="width:184px;height:184px;border-radius:50%;background:#070b10;border:4px solid #4ce5b6;box-shadow:0 0 24px rgba(76,229,182,0.22);color:#fff;font-size:24px;font-weight:800;cursor:pointer;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:4px;">' +
              '<span id="sp-circle-text">Начать</span>' +
              '<span style="font-size:11px;font-weight:700;color:#4ce5b6;text-transform:uppercase;">Тест с роутера</span>' +
            '</button>' +
          '</div>' +
          '<div id="sp-gauge-wrap" class="hidden" style="position:relative;width:300px;height:282px;display:flex;align-items:center;justify-content:center;">' +
            '<canvas id="sp-gauge-canvas" width="600" height="564" style="width:300px;height:282px;display:block;"></canvas>' +
            '<div style="position:absolute;bottom:14px;left:72px;right:72px;text-align:center;pointer-events:none;">' +
              '<div id="sp-gauge-num" style="font-size:38px;font-weight:800;color:#ffffff;line-height:1.0;letter-spacing:-0.5px;">0,00</div>' +
              '<div style="display:inline-flex;align-items:center;justify-content:center;gap:5px;margin-top:4px;">' +
                '<span id="sp-gauge-dir-icon" style="display:inline-flex;align-items:center;justify-content:center;width:15px;height:15px;border-radius:50%;border:1.5px solid #4ce5b6;color:#4ce5b6;font-size:10px;font-weight:900;line-height:1;">↓</span>' +
                '<span id="sp-gauge-phase" style="font-size:13px;font-weight:700;color:#94a3b8;">Мбит/с</span>' +
              '</div>' +
            '</div>' +
          '</div>' +
          '<div id="sp-summary-wrap" class="hidden" style="width:100%;">' +
            '<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:12px;">' +
              '<div style="background:#0d1117;border-radius:14px;padding:12px 14px;">' +
                '<div style="font-size:12px;font-weight:800;color:#4ce5b6;margin-bottom:8px;">↓ ВХОДЯЩАЯ (Мбит/с)</div>' +
                '<div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:4px;"><span style="color:#94a3b8;">Макс</span><strong id="sp-dl-max" style="color:#ffffff;">—</strong></div>' +
                '<div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:4px;"><span style="color:#94a3b8;">Мин</span><strong id="sp-dl-min" style="color:#ffffff;">—</strong></div>' +
                '<div style="display:flex;justify-content:space-between;font-size:13px;"><span style="color:#94a3b8;">Среднее</span><strong id="sp-dl-avg" style="color:#4ce5b6;">—</strong></div>' +
              '</div>' +
              '<div style="background:#0d1117;border-radius:14px;padding:12px 14px;">' +
                '<div style="font-size:12px;font-weight:800;color:#ffb84d;margin-bottom:8px;">↑ ИСХОДЯЩАЯ (Мбит/с)</div>' +
                '<div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:4px;"><span style="color:#94a3b8;">Макс</span><strong id="sp-ul-max" style="color:#ffffff;">—</strong></div>' +
                '<div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:4px;"><span style="color:#94a3b8;">Мин</span><strong id="sp-ul-min" style="color:#ffffff;">—</strong></div>' +
                '<div style="display:flex;justify-content:space-between;font-size:13px;"><span style="color:#94a3b8;">Среднее</span><strong id="sp-ul-avg" style="color:#ffb84d;">—</strong></div>' +
              '</div>' +
            '</div>' +
            '<button type="button" class="btn btn-primary" style="margin-top:0;width:100%;background:#4ce5b6;color:#05080b;font-weight:800;" onclick="window.TestSpeedActivity.start()">Повторить</button>' +
          '</div>' +
        '</div>' +
        '<div class="card" style="padding:14px;margin-bottom:12px;">' +
          '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;">' +
            '<span style="font-size:12px;font-weight:800;color:#4ce5b6;text-transform:uppercase;">Сервер тестирования (РФ)</span>' +
            '<span style="font-size:11.5px;color:#94a3b8;">SSH с роутера</span>' +
          '</div>' +
          '<select id="sp-server-select" onchange="window.TestSpeedActivity.onServerChange()" style="width:100%;background:#151c26;color:#fff;border:none;border-radius:11px;padding:11px 12px;font-size:14px;font-weight:700;outline:none;">' +
            '<option value="yandex">Яндекс CDN (Россия · Москва)</option>' +
            '<option value="selectel">Selectel (Россия · Санкт-Петербург)</option>' +
            '<option value="megafon">МегаФон (Россия)</option>' +
            '<option value="tele2">Tele2 / T2 (Россия)</option>' +
            '<option value="beeline">Билайн (Россия)</option>' +
            '<option value="mts">МТС (Россия)</option>' +
            '<option value="rostelecom">Ростелеком (Россия)</option>' +
            '<option value="domru">Дом.ru (Россия)</option>' +
            '<option value="skynet">SkyNet (Россия · Санкт-Петербург)</option>' +
            '<option value="custom">Свой URL сервера...</option>' +
          '</select>' +
          '<div id="sp-custom-wrap" class="hidden" style="margin-top:8px;">' +
            '<input id="sp-custom-url" type="url" placeholder="http://speedtest.example.com:8080/speedtest/random4000x4000.jpg" style="font-size:14px;padding:11px 12px;">' +
          '</div>' +
          '<div id="sp-error" class="error-banner hidden"></div>' +
        '</div>' +
        '<div style="margin-bottom:10px;">' +
          '<button type="button" class="btn btn-dark" style="margin-top:0;width:100%;display:flex;justify-content:space-between;align-items:center;padding:12px 14px;font-weight:800;" onclick="window.TestSpeedActivity.toggleHistory()">' +
            '<span>Результаты</span>' +
            '<span class="badge badge-up" id="sp-history-count">' + String(loadHistory().length) + '</span>' +
          '</button>' +
        '</div>' +
        '<div id="sp-history-panel" class="card hidden" style="padding:14px;">' +
          '<div style="display:flex;justify-content:space-between;align-items:center;gap:8px;margin-bottom:10px;">' +
            '<span style="font-size:12px;font-weight:800;color:#4ce5b6;text-transform:uppercase;">Журнал результатов</span>' +
            '<button type="button" class="btn btn-sm btn-danger-soft" style="margin-top:0;" onclick="window.TestSpeedActivity.clearHistory()">Очистить журнал</button>' +
          '</div>' +
          '<div id="sp-history-list"></div>' +
        '</div>';
    }
    renderHistoryList();
  }
  var TICKS = [
    { val: 0, label: '0' },
    { val: 5, label: '5' },
    { val: 10, label: '10' },
    { val: 50, label: '50' },
    { val: 100, label: '100' },
    { val: 250, label: '250' },
    { val: 500, label: '500' },
    { val: 750, label: '750' },
    { val: 1000, label: '1k' }
  ];
  function ratioForMbps(mbps) {
    if (mbps <= 0) return 0;
    if (mbps >= 1000) return 1;
    for (var i = 0; i < TICKS.length - 1; i++) {
      var a = TICKS[i].val;
      var b = TICKS[i + 1].val;
      if (mbps <= b) {
        return (i + (mbps - a) / (b - a)) / (TICKS.length - 1);
      }
    }
    return 1;
  }
  function renderGauge(val, col) {
    var canvas = document.getElementById('sp-gauge-canvas');
    if (!canvas) return;
    var ctx = canvas.getContext('2d');
    var w = canvas.width, h = canvas.height;
    ctx.clearRect(0, 0, w, h);
    var cx = w / 2;
    var cy = h * 0.49;
    var rArc = 224;
    var rTickLabel = 172;
    var rNeedleTail = 22;
    var rNeedleTip = 200;
    var a0 = 135 * Math.PI / 180;
    var a1 = 405 * Math.PI / 180;
    var span = a1 - a0;
    ctx.save();
    ctx.lineCap = 'butt';
    ctx.lineWidth = 34;
    ctx.strokeStyle = '#141b24';
    ctx.beginPath();
    ctx.arc(cx, cy, rArc, a0, a1);
    ctx.stroke();
    var ratio = ratioForMbps(val);
    if (ratio > 0.002) {
      var activeEnd = a0 + span * ratio;
      var xStart = cx + Math.cos(a0) * rArc;
      var yStart = cy + Math.sin(a0) * rArc;
      var xEnd = cx + Math.cos(activeEnd) * rArc;
      var yEnd = cy + Math.sin(activeEnd) * rArc;
      var arcGrad = ctx.createLinearGradient(xStart, yStart, xEnd, yEnd);
      if (col === '#ffb84d') {
        arcGrad.addColorStop(0, 'rgba(255, 184, 77, 0.16)');
        arcGrad.addColorStop(0.55, 'rgba(255, 184, 77, 0.72)');
        arcGrad.addColorStop(1, '#ffb84d');
      } else {
        arcGrad.addColorStop(0, 'rgba(76, 229, 182, 0.16)');
        arcGrad.addColorStop(0.55, 'rgba(76, 229, 182, 0.72)');
        arcGrad.addColorStop(1, '#4ce5b6');
      }
      ctx.strokeStyle = arcGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, rArc, a0, activeEnd);
      ctx.stroke();
    }
    ctx.restore();
    ctx.font = '700 22px sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    for (var i = 0; i < TICKS.length; i++) {
      var tRatio = i / (TICKS.length - 1);
      var angT = a0 + span * tRatio;
      var lx = cx + Math.cos(angT) * rTickLabel;
      var ly = cy + Math.sin(angT) * rTickLabel;
      ctx.fillStyle = (val >= TICKS[i].val && TICKS[i].val > 0) ? '#ffffff' : '#cbd5e1';
      ctx.fillText(TICKS[i].label, lx, ly);
    }
    var ang = a0 + span * ratio;
    var perp = ang + Math.PI / 2;
    var tipX = cx + Math.cos(ang) * rNeedleTip;
    var tipY = cy + Math.sin(ang) * rNeedleTip;
    var tailX = cx + Math.cos(ang) * rNeedleTail;
    var tailY = cy + Math.sin(ang) * rNeedleTail;
    var tipHalfW = 11;
    var tailHalfW = 2.5;
    var p1x = tipX + Math.cos(perp) * tipHalfW;
    var p1y = tipY + Math.sin(perp) * tipHalfW;
    var p2x = tipX - Math.cos(perp) * tipHalfW;
    var p2y = tipY - Math.sin(perp) * tipHalfW;
    var p3x = tailX - Math.cos(perp) * tailHalfW;
    var p3y = tailY - Math.sin(perp) * tailHalfW;
    var p4x = tailX + Math.cos(perp) * tailHalfW;
    var p4y = tailY + Math.sin(perp) * tailHalfW;
    var needleGrad = ctx.createLinearGradient(tailX, tailY, tipX, tipY);
    needleGrad.addColorStop(0, 'rgba(255, 255, 255, 0.02)');
    needleGrad.addColorStop(0.35, 'rgba(203, 213, 225, 0.35)');
    needleGrad.addColorStop(0.85, 'rgba(255, 255, 255, 0.92)');
    needleGrad.addColorStop(1, '#ffffff');
    ctx.fillStyle = needleGrad;
    ctx.beginPath();
    ctx.moveTo(p1x, p1y);
    ctx.lineTo(p2x, p2y);
    ctx.lineTo(p3x, p3y);
    ctx.lineTo(p4x, p4y);
    ctx.closePath();
    ctx.fill();
  }
  function formatSpeedComma(v) {
    return v.toFixed(2).replace('.', ',');
  }
  function startAnim() {
    stopAnim();
    animTimer = setInterval(function() {
      currentVal += (targetVal - currentVal) * 0.22;
      if (Math.abs(targetVal - currentVal) < 0.02) currentVal = targetVal;
      renderGauge(currentVal, accentColor);
      var num = document.getElementById('sp-gauge-num');
      if (num) num.textContent = formatSpeedComma(currentVal);
    }, 35);
  }
  function stopAnim() {
    if (animTimer) {
      clearInterval(animTimer);
      animTimer = null;
    }
  }
  function setGaugeDir(isUpload) {
    accentColor = isUpload ? '#ffb84d' : '#4ce5b6';
    var dirIcon = document.getElementById('sp-gauge-dir-icon');
    if (dirIcon) {
      dirIcon.textContent = isUpload ? '↑' : '↓';
      dirIcon.style.color = accentColor;
      dirIcon.style.borderColor = accentColor;
    }
  }
  function showSummaryPanel(dlStats, ulStats) {
    stopAnim();
    var g = document.getElementById('sp-gauge-wrap');
    var c = document.getElementById('sp-circle-wrap');
    var s = document.getElementById('sp-summary-wrap');
    if (g) g.classList.add('hidden');
    if (c) c.classList.add('hidden');
    if (s) s.classList.remove('hidden');
    function setStat(prefix, st) {
      var maxEl = document.getElementById(prefix + '-max');
      var minEl = document.getElementById(prefix + '-min');
      var avgEl = document.getElementById(prefix + '-avg');
      if (!st || !st.hasData) {
        if (maxEl) maxEl.textContent = 'Н/Д';
        if (minEl) minEl.textContent = 'Н/Д';
        if (avgEl) avgEl.textContent = 'Н/Д';
        return;
      }
      if (maxEl) maxEl.textContent = st.max.toFixed(2);
      if (minEl) minEl.textContent = st.min.toFixed(2);
      if (avgEl) avgEl.textContent = st.avg.toFixed(2);
    }
    setStat('sp-dl', dlStats);
    setStat('sp-ul', ulStats);
  }
  function shQuote(s) {
    return "'" + String(s).replace(/'/g, "'\\''") + "'";
  }
  function sleep(ms) {
    return new Promise(function(r) { setTimeout(r, ms); });
  }
  // Sliding-window average over last ~2.5s so needle moves smoothly without 15 -> 1 -> 18 jumps
  function slidingMbps(history, curBytes, curSec) {
    history.push({ b: curBytes, t: curSec });
    while (history.length > 2 && (curSec - history[0].t) > 2.6) {
      history.shift();
    }
    var base = history[0];
    var db = curBytes - base.b;
    var dt = curSec - base.t;
    if (db <= 0 || dt < 0.15) return null;
    return (db * 8) / (dt * 1000000);
  }
  async function runSpeedTest() {
    if (running) return;
    running = true;
    initDom();
    var sel = document.getElementById('sp-server-select');
    var key = sel ? sel.value : 'yandex';
    var serverLabel = (sel && sel.options && sel.selectedIndex >= 0) ? sel.options[sel.selectedIndex].text : 'Сервер';
    var pingHost = '77.88.8.8';
    var dlUrls = [];
    var ulUrls = [];
    if (key === 'custom') {
      var rawUrl = ((document.getElementById('sp-custom-url') || {}).value || '').trim();
      if (!rawUrl) {
        running = false;
        var err1 = document.getElementById('sp-error');
        if (err1) { err1.textContent = 'Укажите URL сервера'; err1.classList.remove('hidden'); }
        return;
      }
      serverLabel = rawUrl;
      dlUrls = [rawUrl];
      ulUrls = [rawUrl];
      try { pingHost = new URL(rawUrl.indexOf('http') === 0 ? rawUrl : 'http://' + rawUrl).hostname; } catch (_) {}
    } else {
      var srv = SERVERS[key] || SERVERS.yandex;
      pingHost = srv.pingHost;
      dlUrls = srv.dlUrls;
      ulUrls = srv.ulUrls;
    }
    var cWrap = document.getElementById('sp-circle-wrap');
    var gWrap = document.getElementById('sp-gauge-wrap');
    var sWrap = document.getElementById('sp-summary-wrap');
    var phase = document.getElementById('sp-gauge-phase');
    var badge = document.getElementById('sp-status');
    var errEl = document.getElementById('sp-error');
    var dlOut = document.getElementById('sp-dl-val');
    var ulOut = document.getElementById('sp-ul-val');
    var ulUnit = document.getElementById('sp-ul-unit');
    var pingOut = document.getElementById('sp-ping-val');
    var jitOut = document.getElementById('sp-jitter-val');
    if (errEl) { errEl.classList.add('hidden'); errEl.textContent = ''; }
    if (cWrap) cWrap.classList.add('hidden');
    if (sWrap) sWrap.classList.add('hidden');
    if (gWrap) gWrap.classList.remove('hidden');
    if (dlOut) dlOut.textContent = '—';
    if (ulOut) ulOut.textContent = '—';
    if (ulUnit) ulUnit.textContent = 'Мбит/с';
    if (pingOut) pingOut.textContent = '—';
    if (jitOut) jitOut.textContent = '—';
    currentVal = 0;
    targetVal = 0;
    setGaugeDir(false);
    if (phase) { phase.textContent = 'Мбит/с'; }
    if (badge) { badge.textContent = 'Ping...'; badge.className = 'badge badge-up'; }
    startAnim();
    try {
      // 1. Ping & Jitter
      var pingCmd = 'P_OUT=$(ping -c 4 -W 2 ' + shQuote(pingHost) + ' 2>/dev/null || ping -c 4 -W 2 77.88.8.8 2>/dev/null); ' +
        'RTT_LIST=$(echo "$P_OUT" | sed -n \'s/.*time=\([0-9.][0-9.]*\).*/\1/p\'); ' +
        'AVG_MS=$(echo "$P_OUT" | awk -F\'/\' \'/round-trip|rtt/ {print $5}\'); ' +
        'echo "RTT:$RTT_LIST"; echo "AVG:$AVG_MS"';
      var pRes = await callSsh(pingCmd);
      if (!pRes || !pRes.ok) throw new Error((pRes && pRes.error) || 'Нет SSH-соединения');
      var rttRaw = '', avgMs = '';
      (pRes.output || '').split('\n').forEach(function(line) {
        if (line.indexOf('RTT:') === 0) rttRaw = line.slice(4).trim();
        if (line.indexOf('AVG:') === 0) avgMs = line.slice(4).trim();
      });
      var rtts = rttRaw.split(/\s+/).map(Number).filter(function(n) { return !isNaN(n) && n >= 0; });
      if (avgMs && !isNaN(parseFloat(avgMs))) {
        if (pingOut) pingOut.textContent = parseFloat(avgMs).toFixed(1);
      } else if (rtts.length > 0) {
        var sum = rtts.reduce(function(a, b) { return a + b; }, 0);
        if (pingOut) pingOut.textContent = (sum / rtts.length).toFixed(1);
      }
      if (rtts.length >= 2) {
        var dSum = 0;
        for (var i = 1; i < rtts.length; i++) dSum += Math.abs(rtts[i] - rtts[i - 1]);
        if (jitOut) jitOut.textContent = (dSum / (rtts.length - 1)).toFixed(1);
      }
      // 2. Download phase (10s, 4 parallel streams, 2.5s sliding window over /proc/net/dev RX)
      setGaugeDir(false);
      if (badge) badge.textContent = 'Скачивание...';
      var urlsArg = dlUrls.map(shQuote).join(' ');
      var startDlCmd = 'rm -f /tmp/sp_dl.pid /tmp/sp_dl.done; ' +
        'IFACE=$(ip route get 77.88.8.8 2>/dev/null | awk \'{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1); exit}}\'); ' +
        '[ -z "$IFACE" ] && IFACE=$(ip route show default 2>/dev/null | awk \'/default/ {print $5; exit}\'); ' +
        'PICKED=""; for U in ' + urlsArg + '; do ' +
        'if command -v curl >/dev/null 2>&1; then ' +
        'C=$(curl -s -L -o /dev/null --connect-timeout 3 --max-time 4 -r 0-65535 -w "%{http_code}" "$U" 2>/dev/null); ' +
        '[ "$C" = "200" ] || [ "$C" = "206" ] && { PICKED="$U"; break; }; ' +
        'elif command -v wget >/dev/null 2>&1; then ' +
        'wget -q -T 4 --spider "$U" 2>/dev/null && { PICKED="$U"; break; }; fi; done; ' +
        'if [ -z "$PICKED" ]; then echo "ERR_NO_URL"; exit 0; fi; ' +
        'if command -v curl >/dev/null 2>&1; then ' +
        '( trap "touch /tmp/sp_dl.done; kill -9 $J1 $J2 2>/dev/null; killall -9 curl 2>/dev/null; rm -f /tmp/sp_dl.pid /tmp/sp_dl.done; exit 0" TERM INT HUP; (while [ ! -f /tmp/sp_dl.done ]; do curl -s -L -o /dev/null --max-time 6 "$PICKED?r=1" >/dev/null 2>&1 || break; done) >/dev/null 2>&1 & J1=$!; (while [ ! -f /tmp/sp_dl.done ]; do curl -s -L -o /dev/null --max-time 6 "$PICKED?r=2" >/dev/null 2>&1 || break; done) >/dev/null 2>&1 & J2=$!; sleep 10; touch /tmp/sp_dl.done; kill -9 $J1 $J2 2>/dev/null; killall -9 curl 2>/dev/null; wait 2>/dev/null; rm -f /tmp/sp_dl.pid /tmp/sp_dl.done ) >/dev/null 2>&1 & echo $! > /tmp/sp_dl.pid; ' +
        'else ' +
        '( wget -q -T 10 -O /dev/null "$PICKED" >/dev/null 2>&1; touch /tmp/sp_dl.done ) >/dev/null 2>&1 & echo $! > /tmp/sp_dl.pid; fi; ' +
        'RX=$(awk -v dev="$IFACE" -F"[: ]+" \'$0 ~ dev {for(i=1;i<=NF;i++) if($i==dev){print $(i+1); exit}}\' /proc/net/dev); ' +
        'UP=$(awk \'{print $1}\' /proc/uptime); ' +
        'echo "OK:$IFACE:$RX:$UP"';
      var stDl = await callSsh(startDlCmd);
      var dlFinal = 0;
      var dlSamples = [];
      if (stDl && stDl.ok && (stDl.output || '').indexOf('OK:') !== -1) {
        var initParts = '';
        (stDl.output || '').split('\n').forEach(function(l) {
          if (l.indexOf('OK:') === 0) initParts = l.slice(3).trim();
        });
        var pArr = initParts.split(':');
        var iface = pArr[0] || '';
        var startBytes = parseFloat(pArr[1]);
        var startSec = parseFloat(pArr[2]);
        var dlHistory = [{ b: startBytes, t: startSec }];
        var lastBytes = startBytes;
        var lastSec = startSec;
        var pollDlCmd = 'RX=$(awk -v dev=' + shQuote(iface) + ' -F"[: ]+" \'$0 ~ dev {for(i=1;i<=NF;i++) if($i==dev){print $(i+1); exit}}\' /proc/net/dev); ' +
          'UP=$(awk \'{print $1}\' /proc/uptime); ' +
          'ALIVE=0; if [ -f /tmp/sp_dl.pid ] && [ ! -f /tmp/sp_dl.done ]; then P=$(cat /tmp/sp_dl.pid 2>/dev/null); [ -n "$P" ] && kill -0 "$P" 2>/dev/null && ALIVE=1; fi; ' +
          'echo "TICK:$ALIVE:$RX:$UP"';
        for (var step = 0; step < 26; step++) {
          await sleep(380);
          var tickRes = await callSsh(pollDlCmd);
          if (!tickRes || !tickRes.ok) break;
          var tickLine = '';
          (tickRes.output || '').split('\n').forEach(function(l) {
            if (l.indexOf('TICK:') === 0) tickLine = l.slice(5).trim();
          });
          if (!tickLine) continue;
          var tp = tickLine.split(':');
          var alive = tp[0] === '1';
          var curBytes = parseFloat(tp[1]);
          var curSec = parseFloat(tp[2]);
          if (!isNaN(curBytes) && !isNaN(curSec) && curBytes >= lastBytes) {
            lastBytes = curBytes;
            lastSec = curSec;
            var smooth = slidingMbps(dlHistory, curBytes, curSec);
            if (smooth !== null && smooth > 0.05) {
              targetVal = smooth;
              dlSamples.push(smooth);
              if (dlOut) dlOut.textContent = smooth.toFixed(2);
            }
          }
          if (!alive) break;
        }
        await callSsh('touch /tmp/sp_dl.done; P=$(cat /tmp/sp_dl.pid 2>/dev/null); [ -n "$P" ] && kill -9 "$P" 2>/dev/null; killall -9 curl wget uclient-fetch 2>/dev/null; rm -f /tmp/sp_dl.pid /tmp/sp_dl.done');
        var totalDt = lastSec - startSec;
        var totalDb = lastBytes - startBytes;
        if (totalDt > 0.5 && totalDb > 0) {
          dlFinal = (totalDb * 8) / (totalDt * 1000000);
        }
      }
      if (dlFinal > 0.05) {
        targetVal = dlFinal;
        if (dlOut) dlOut.textContent = dlFinal.toFixed(2);
      } else if (dlOut) {
        dlOut.textContent = 'Н/Д';
      }
      await sleep(550);
      // 3. Upload phase (10s, fixed-size binary payload file /tmp/sp_up.bin so curl sends Content-Length instead of chunked!)
      currentVal = 0;
      targetVal = 0;
      setGaugeDir(true);
      if (badge) badge.textContent = 'Отдача...';
      var ulUrlsArg = ulUrls.map(shQuote).join(' ');
      var startUlCmd = 'rm -f /tmp/sp_ul.pid /tmp/sp_ul.done /tmp/sp_up.bin /tmp/sp_up_probe.bin; ' +
        'IFACE=$(ip route get 77.88.8.8 2>/dev/null | awk \'{for(i=1;i<=NF;i++) if($i=="dev"){print $(i+1); exit}}\'); ' +
        '[ -z "$IFACE" ] && IFACE=$(ip route show default 2>/dev/null | awk \'/default/ {print $5; exit}\'); ' +
        'dd if=/dev/zero of=/tmp/sp_up_probe.bin bs=4096 count=4 2>/dev/null; ' +
        'YA_PROBES=""; if command -v curl >/dev/null 2>&1; then ' +
        'YA_PROBES=$(curl -s -k --connect-timeout 2 --max-time 3 "https://yandex.ru/internet/api/v0/get-probes" 2>/dev/null | tr "\\"{}[], " "\\n" | grep -E "^https?://" | grep -E "yandex\\.net|strm|cdn" | head -n 8); ' +
        'fi; ' +
        'PICKED_UL=""; ' +
        'if command -v curl >/dev/null 2>&1; then ' +
        '  for U in $YA_PROBES; do ' +
        '    CODE=$(curl -s -k -o /dev/null --connect-timeout 1 --max-time 2 -H "Expect:" -X POST --data-binary @/tmp/sp_up_probe.bin -w "%{http_code}" "$U" 2>/dev/null); ' +
        '    if [ "$CODE" = "200" ] || [ "$CODE" = "201" ] || [ "$CODE" = "204" ]; then PICKED_UL="$U"; break; fi; ' +
        '  done; ' +
        '  if [ -z "$PICKED_UL" ]; then ' +
        '    for U in ' + ulUrlsArg + '; do ' +
        '      CODE=$(curl -s -k -o /dev/null --connect-timeout 1 --max-time 2 -H "Expect:" -X POST --data-binary @/tmp/sp_up_probe.bin -w "%{http_code}" "$U" 2>/dev/null); ' +
        '      if [ "$CODE" = "200" ] || [ "$CODE" = "201" ] || [ "$CODE" = "204" ]; then PICKED_UL="$U"; break; fi; ' +
        '    done; ' +
        '  fi; ' +
        'fi; ' +
        'if [ -z "$PICKED_UL" ]; then ' +
        '  UL_BIN=""; command -v wget >/dev/null 2>&1 && UL_BIN="wget"; [ -z "$UL_BIN" ] && command -v uclient-fetch >/dev/null 2>&1 && UL_BIN="uclient-fetch"; ' +
        '  if [ -n "$UL_BIN" ]; then ' +
        '    for U in $YA_PROBES ' + ulUrlsArg + '; do ' +
        '      if $UL_BIN -q --no-check-certificate -T 2 -O /dev/null --post-file=/tmp/sp_up_probe.bin "$U" >/dev/null 2>&1; then PICKED_UL="$U"; break; fi; ' +
        '    done; ' +
        '  fi; ' +
        'fi; ' +
        'rm -f /tmp/sp_up_probe.bin; ' +
        '[ -z "$PICKED_UL" ] && PICKED_UL=$(printf "%s\\n" $YA_PROBES | head -n 1); ' +
        '[ -z "$PICKED_UL" ] && PICKED_UL=https://ya.ru; ' +
        'SEP="?"; case "$PICKED_UL" in *\\?*) SEP="&";; esac; ' +
        'dd if=/dev/zero of=/tmp/sp_up.bin bs=65536 count=8 2>/dev/null; ' +
        'if command -v curl >/dev/null 2>&1; then ' +
        '  ( trap "touch /tmp/sp_ul.done; kill -9 $W1 $W2 2>/dev/null; killall -9 wget uclient-fetch 2>/dev/null; rm -f /tmp/sp_ul.pid /tmp/sp_ul.done /tmp/sp_up.bin; exit 0" TERM INT HUP; (while [ ! -f /tmp/sp_ul.done ]; do $UL_BIN -q --no-check-certificate -T 6 -O /dev/null --post-file=/tmp/sp_up.bin "${PICKED_UL}${SEP}u=1" >/dev/null 2>&1 || sleep 0.1; done) >/dev/null 2>&1 & W1=$!; (while [ ! -f /tmp/sp_ul.done ]; do $UL_BIN -q --no-check-certificate -T 6 -O /dev/null --post-file=/tmp/sp_up.bin "${PICKED_UL}${SEP}u=2" >/dev/null 2>&1 || sleep 0.1; done) >/dev/null 2>&1 & W2=$!; sleep 10; touch /tmp/sp_ul.done; kill -9 $W1 $W2 2>/dev/null; killall -9 wget uclient-fetch 2>/dev/null; wait 2>/dev/null; rm -f /tmp/sp_ul.pid /tmp/sp_ul.done /tmp/sp_up.bin ) >/dev/null 2>&1 & echo $! > /tmp/sp_ul.pid; ' +
        'else ' +
        '  UL_BIN=""; command -v wget >/dev/null 2>&1 && UL_BIN="wget"; [ -z "$UL_BIN" ] && command -v uclient-fetch >/dev/null 2>&1 && UL_BIN="uclient-fetch"; ' +
        '  ( trap "touch /tmp/sp_ul.done; kill -9 $W1 $W2 2>/dev/null; killall -9 wget uclient-fetch 2>/dev/null; rm -f /tmp/sp_ul.pid /tmp/sp_ul.done /tmp/sp_up.bin; exit 0" TERM INT HUP; (while [ ! -f /tmp/sp_ul.done ]; do $UL_BIN -q --no-check-certificate -T 6 -O /dev/null --post-file=/tmp/sp_up.bin "${PICKED_UL}${SEP}u=1" >/dev/null 2>&1 || sleep 0.1; done) >/dev/null 2>&1 & W1=$!; (while [ ! -f /tmp/sp_ul.done ]; do $UL_BIN -q --no-check-certificate -T 6 -O /dev/null --post-file=/tmp/sp_up.bin "${PICKED_UL}${SEP}u=2" >/dev/null 2>&1 || sleep 0.1; done) >/dev/null 2>&1 & W2=$!; sleep 10; touch /tmp/sp_ul.done; kill -9 $W1 $W2 2>/dev/null; killall -9 wget uclient-fetch 2>/dev/null; wait 2>/dev/null; rm -f /tmp/sp_ul.pid /tmp/sp_ul.done /tmp/sp_up.bin ) >/dev/null 2>&1 & echo $! > /tmp/sp_ul.pid; ' +
        'fi; ' +
        'TX=$(awk -v dev="$IFACE" -F"[: ]+" \'$0 ~ dev {for(i=1;i<=NF;i++) if($i==dev){print $(i+9); exit}}\' /proc/net/dev); ' +
        'UP=$(awk \'{print $1}\' /proc/uptime); ' +
        'echo "OK:$IFACE:$TX:$UP"';
      var stUl = await callSsh(startUlCmd);
      var ulFinal = 0;
      var ulSamples = [];
      var noCurl = (stUl && (stUl.output || '').indexOf('UL_NOWGET') !== -1);
      if (stUl && stUl.ok && (stUl.output || '').indexOf('OK:') !== -1) {
        var uInit = '';
        (stUl.output || '').split('\n').forEach(function(l) {
          if (l.indexOf('OK:') === 0) uInit = l.slice(3).trim();
        });
        var upArr = uInit.split(':');
        var uIface = upArr[0] || '';
        var uStartBytes = parseFloat(upArr[1]);
        var uStartSec = parseFloat(upArr[2]);
        var ulHistory = [{ b: uStartBytes, t: uStartSec }];
        var uLastBytes = uStartBytes;
        var uLastSec = uStartSec;
        var pollUlCmd = 'TX=$(awk -v dev=' + shQuote(uIface) + ' -F"[: ]+" \'$0 ~ dev {for(i=1;i<=NF;i++) if($i==dev){print $(i+9); exit}}\' /proc/net/dev); ' +
          'UP=$(awk \'{print $1}\' /proc/uptime); ' +
          'ALIVE=0; if [ -f /tmp/sp_ul.pid ] && [ ! -f /tmp/sp_ul.done ]; then P=$(cat /tmp/sp_ul.pid 2>/dev/null); [ -n "$P" ] && kill -0 "$P" 2>/dev/null && ALIVE=1; fi; ' +
          'echo "TICK:$ALIVE:$TX:$UP"';
        for (var uStep = 0; uStep < 26; uStep++) {
          await sleep(380);
          var uTick = await callSsh(pollUlCmd);
          if (!uTick || !uTick.ok) break;
          var uLine = '';
          (uTick.output || '').split('\n').forEach(function(l) {
            if (l.indexOf('TICK:') === 0) uLine = l.slice(5).trim();
          });
          if (!uLine) continue;
          var utp = uLine.split(':');
          var uAlive = utp[0] === '1';
          var uCurBytes = parseFloat(utp[1]);
          var uCurSec = parseFloat(utp[2]);
          if (!isNaN(uCurBytes) && !isNaN(uCurSec) && uCurBytes >= uLastBytes) {
            uLastBytes = uCurBytes;
            uLastSec = uCurSec;
            var uSmooth = slidingMbps(ulHistory, uCurBytes, uCurSec);
            if (uSmooth !== null && uSmooth > 0.05) {
              targetVal = uSmooth;
              ulSamples.push(uSmooth);
              if (ulOut) ulOut.textContent = uSmooth.toFixed(2);
            }
          }
          if (!uAlive) break;
        }
        await callSsh('touch /tmp/sp_ul.done; P=$(cat /tmp/sp_ul.pid 2>/dev/null); [ -n "$P" ] && kill -9 "$P" 2>/dev/null; killall -9 curl wget uclient-fetch 2>/dev/null; rm -f /tmp/sp_ul.pid /tmp/sp_ul.done /tmp/sp_up.bin /tmp/sp_up_probe.bin');
        var uTotalDt = uLastSec - uStartSec;
        var uTotalDb = uLastBytes - uStartBytes;
        if (uTotalDt > 0.5 && uTotalDb > 0) {
          ulFinal = (uTotalDb * 8) / (uTotalDt * 1000000);
        }
      }
      var dlStats = calcStats(dlSamples, dlFinal);
      var ulStats = calcStats(ulSamples, ulFinal);
      if (ulFinal > 0.05) {
        targetVal = ulFinal;
        if (ulOut) ulOut.textContent = ulFinal.toFixed(2);
      } else if (ulOut) {
        ulOut.textContent = 'Н/Д';
        if (ulUnit && noCurl) ulUnit.textContent = 'нет wget';
      }
      recordResult({
        ts: Date.now(),
        server: serverLabel,
        ping: pingOut ? pingOut.textContent : '',
        jitter: jitOut ? jitOut.textContent : '',
        dl: dlStats,
        ul: ulStats
      });
      await sleep(550);
      if (badge) { badge.textContent = 'Готово'; badge.className = 'badge badge-up'; }
      showSummaryPanel(dlStats, ulStats);
    } catch (e) {
      if (errEl) { errEl.textContent = 'Ошибка: ' + (e && e.message ? e.message : e); errEl.classList.remove('hidden'); }
      if (badge) { badge.textContent = 'Ошибка'; badge.className = 'badge badge-down'; }
      showSummaryPanel({ hasData: false }, { hasData: false });
    } finally {
      running = false;
    }
  }
  window.TestSpeedActivity = {
    init: initDom,
    start: runSpeedTest,
    toggleHistory: toggleHistoryPanel,
    clearHistory: clearHistory,
    onServerChange: function() {
      var sel = document.getElementById('sp-server-select');
      var wrap = document.getElementById('sp-custom-wrap');
      if (sel && wrap) wrap.classList.toggle('hidden', sel.value !== 'custom');
    }
  };
})();